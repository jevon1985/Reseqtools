#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include "./src/include/zlib/zlib.h"
#include "./src/ALL/kseq.h"
#include "./src/ALL/comm.h"
#include "./src/Soap/SOAPTools.h"
#include "./src/Other/OtherTool.h"
#include "./src/CNSTool/CNSTools.h"
#include "./src/Form/FormTools.h"
#include "./src/FaDeal/FaTools.h"
#include "./src/Fq/FqTools.h"
#include "./src/Xam/XamTools.h"
#include "./src/File/FileTool.h"
#include "./src/Game/GameTool.h"
#include "./src/Other/HelpTemp.h"
#include "./src/Gff/GffTool.h"
#include "./src/Variants/VariantsTools.h"
//#include "./src/sam/samtools.c"

using namespace std;

int SOAP_Tools_main(int argc, char *argv[]) ;
int Other_Tools_main(int argc, char *argv[]);
int CNS_Tools_main(int argc, char *argv[]) ;
int Form_Tools_main(int argc, char *argv[]) ;
int Fa_Tools_main(int argc, char *argv[]) ;
int FQ_Tools_main(int argc, char *argv[]) ;
//int Sam_Tools_main(int argc, char *argv[]);
int Xam_Tools_main(int argc, char *argv[]) ;
int File_Tools_main(int argc, char *argv[]);
int Gff_Tools_main(int argc, char *argv[]);
int help_main ( int argc , char *argv[]  ) ;
int Game_Tools_main(int argc, char *argv[])  ;
int Var_Tools_main(int argc, char *argv[]) ;

static int  AllTools_usage ()
{
    cerr <<"Program: iTools (ReSeqtools)\nVersion: 0.20\thewm2008@gmail.com\t"<<__DATE__<<endl;
    //cerr <<"Program: iTools (ReSeqtools)\n"<<__DATE__<<"\nVersion: 0.18\thewm2008@gmail.com\tQQ Group:125293663"<<endl;

    cerr<<""
        "\n"
        "\tUsage:\n\n"
        "\t\tFatools        Tools For Fasta\n"
        "\t\tFqtools        Tools For Fastq\n"
        "\t\tSOAPtools      Tools For SOAP \n"
        "\t\tVartools       Tools For SOAP Variant\n"
//       "\t\tsamtools       Tools For Sam,Bam\n"
        "\t\tCNStools       Tools For CNS\n"
        "\t\tXamtools       Tools For Sam/Bam\n"
        "\t\tGfftools       Tools For Gff\n"
        "\t\tFormtools      Tools For Form convert\n"
        "\t\tFiletools      Tools For Specified File\n"
        "\t\tOthertools     Tools For Other\n"
        "\t\tGametools      Tools For Game\n"
        "\n"
        "\t\tHelp           Show help in detail\n"
        "\n";
    return 1;
}

int main(int argc, char *argv[])
{
    if (argc < 2) { return AllTools_usage(); }
    else if (strcmp(argv[1], "SOAPtools") == 0) { return SOAP_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "samtools") == 0) { return Xam_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "CNStools") == 0) { return CNS_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Vartools") == 0) { return Var_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Fatools") == 0) { return Fa_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Fqtools") == 0) { return FQ_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Formtools") == 0) { return Form_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Xamtools") == 0) { return Xam_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Othertools") == 0) { return Other_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Filetools") == 0) { return File_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Gfftools") == 0) { return Gff_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Gametools") == 0) { return Game_Tools_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Help") == 0 || strcmp(argv[1], "help") == 0 || strcmp(argv[1], "?")== 0 || ( argv[1][0] == '-' &&( argv[1][1] =='h' || argv[1][1] =='H' || argv[1][1] =='?' ) )  || strcmp(argv[1], "less") == 0 )
    {
        return help_main (argc , argv );
    }
    else
    {
        cerr<<"iTools[main] unrecognized command "<<argv[1]<<endl;
        return 1;
    }
    return 0;	
}


