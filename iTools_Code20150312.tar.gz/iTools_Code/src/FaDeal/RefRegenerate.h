#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include <algorithm>
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"

using namespace std;
typedef long long  llong ;

class Para_FA05 {
	public:
		string InPut ;
		string OutPut ;
		int insertN ;
		llong length ;
		int NumSeq ;
		string oriChr ;
		string newChr ;
		bool GZNo;
		Para_FA05()
		{
			InPut="";
			OutPut="";
			insertN=100;
			length=0;
			oriChr="Chr";
			newChr="NewChr";
			NumSeq=20;
			GZNo=false ;
		}
};


int  usage_FA05()
{
	cout <<""
		"\n"
		"\tUsage: regenerate -InPut <in.fa> -OutPut <out.fa> \n"
		"\n"
		"\t\t-InPut    <str>   Input fa for regenerate\n"
		"\t\t-OutPut   <str>   Output file fa of new Ref\n"
		"\n"
		"\t\t-OriChr   <str>   Original chr name for NoChang[Chr]\n"
		"\t\t-NewChr   <str>   New Chr for merge Seq[NewChr]\n"
		"\t\t-InsertN  <int>   Insert Num of N between two Scaf [100]\n"
		"\t\t-NumSeq   <int>   the Num for merge new Seq [20]\n"
		"\t\t-Length   <int>   Len of each new merge Seq [NA]\n"
		"\t\t-NoOutgz          OutPut file with No gz [NA]\n"
		"\n"
		"\t\t-help             show this help\n"
		"\n";
	return 1;
}


int parse_Acmd_FA05(int argc, char **argv , Para_FA05 * para_FA05 )
{
	if (argc <=2 ) {usage_FA05();return 0;}

	int tmp=0 ;
	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_FA05->InPut=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA05->OutPut=argv[i];
		}       
		else if (flag  ==  "InsertN")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA05->insertN=atoi(argv[i]);
		}
		else if (flag  == "NumSeq")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA05->NumSeq=atoi(argv[i]);
			tmp++;
		}
		else if (flag  == "Length")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA05->length=atol(argv[i]);
			tmp++;
		}
		else if (flag  == "OriChr")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA05->oriChr=argv[i];
		}
		else if (flag  == "NewChr")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA05->newChr=argv[i];
		}
		else if (flag  == "NoOutgz")
		{
			para_FA05->GZNo=true;
		}
		else if (flag  == "help")
		{
			usage_FA05();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_FA05->InPut).empty() || (para_FA05->OutPut).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	if (tmp>1)
	{
		cerr<< "para -Length & -NumSeq should not together"<<endl ;
		return 0;
	}
	return 1 ;
}




//int main(int argc, char *argv[])
int FA_Regenerate_main(int argc, char *argv[])
{
	Para_FA05 * para_FA05 = new Para_FA05;
	if( parse_Acmd_FA05(argc, argv, para_FA05 )==0)
	{
		delete  para_FA05 ;
		return 0;    
	}

	int linecut= FaCutLine ((para_FA05->InPut));

	string mergelist=(para_FA05->OutPut)+".merlist";
	(para_FA05->OutPut)=add_Asuffix((para_FA05->OutPut));
	string chrlist=(para_FA05->OutPut)+".chrlist";
	ofstream  MER (mergelist.c_str());
	ogzstream  OUT ((para_FA05->OutPut).c_str());
	if(!OUT.good())
	{
		cerr << "open OUT File error: "<<(para_FA05->OutPut)<<endl;
		return 0;
	}
	if (MER.fail())
	{
		cerr << "open OUT File error: "<<mergelist<<endl;
		return 0;
	}

	MER<<"##OldChr\tStart\tEnd\tNewChr\tStart\tEnd"<<endl;

	gzFile fp;
	kseq_t *seq;
	int l;
	fp = gzopen((para_FA05->InPut).c_str(), "r");
	seq = kseq_init(fp);
	map <string ,llong > ChrLen ;
	map <string ,string> ChrSeq ;
	map <llong ,vector <string> > SortLeng ;
	llong SumLeng=0;

	while ((l = kseq_read(seq)) >= 0) 
	{
		string RefSeq=(seq->seq.s);
		string chr=(seq->name.s);
		llong seq_length = (seq->seq.l);
		if (chr.find(para_FA05->oriChr) == string::npos)
		{
			ChrLen[chr]=seq_length;
			ChrSeq[chr]=RefSeq;
			SumLeng+=(seq_length+(para_FA05->insertN));
			map <llong ,vector <string> > ::iterator it=SortLeng.find(seq_length) ;
			if (it==SortLeng.end())
			{
				vector <string> tmp;
				tmp.push_back(chr);
				SortLeng.insert(map <llong,vector <string> > ::value_type(seq_length,tmp));
			}
			else
			{
				(it->second).push_back(chr);
			}
		}
		else
		{
			if (seq->comment.l)
			{
				string tmp=seq->comment.s;
				chr=chr+"\t"+tmp;
			}
			Display( RefSeq , chr  , OUT ,linecut);
			MER<<chr<<"\t1\t"<<seq_length<<"\t"<<chr<<"\t1\t"<<seq_length<<endl;
		}
	}

	kseq_destroy(seq);
	gzclose(fp);
	vector <string>  SortChr ;
	map <llong ,vector <string> > ::iterator it=SortLeng.begin();
	for ( ; it!=SortLeng.end();it++)
	{
		int Size=(it->second).size();
		for (int ii=0; ii<Size ; ii++)
		{
			SortChr.push_back((it->second)[ii]);
		}
	}
	SortLeng.clear();

	llong Each_NewSeq_length=(SumLeng/(para_FA05->NumSeq));
	if ((para_FA05->length)!=0)
	{
		Each_NewSeq_length=para_FA05->length;
	}

	string N; 
	for (int jj=0; jj<(para_FA05->insertN) ;  jj++ )
	{
		N+="N";
	}


	int size_length=SortChr.size();
	llong Tmp=0;
	int New_chr_ID=1;
	string  ID=(para_FA05->newChr)+Int2Str(New_chr_ID);

	for (int i=size_length-1; i>-1; i--)
	{
		if (Tmp==0)
		{
			Tmp=ChrLen[SortChr[i]];
			ID=(para_FA05->newChr)+Int2Str(New_chr_ID);
			New_chr_ID++;
			OUT<<">"<<ID<<endl ;
			Display( ChrSeq[SortChr[i]] , OUT , linecut);
			MER<<SortChr[i]<<"\t1\t"<<Tmp<<"\t"<<ID<<"\t1\t"<<Tmp<<endl;
			if (Tmp>Each_NewSeq_length)
			{
				Tmp=0;
			}			
		}
		else
		{
			Display( N  , OUT , linecut );
			Display( ChrSeq[SortChr[i]] , OUT , linecut);
			llong tmpLength=ChrLen[SortChr[i]];
			Tmp+=(para_FA05->insertN);
			MER<<SortChr[i]<<"\t1\t"<<tmpLength<<"\t"<<ID<<"\t"<<(Tmp+1)<<"\t";
			Tmp+=tmpLength;
			MER<<Tmp<<endl;
			if (Tmp>Each_NewSeq_length)
			{
				Tmp=0;
			}
		}
	}

	OUT.close();

	char * A = const_cast<char*>((para_FA05->OutPut).c_str());
	string DD=(para_FA05->OutPut)+".filter.gz";
	char * C = const_cast<char*>((DD).c_str());
	char * TmpFF[9]={"filter", "-InPut", A , "-OutPut" , C , "-MinLen" ,"100", "-NRatio", "0.88" };
	FA_Filter_main( 9 , TmpFF );
	string  MV="mv  "+DD+" "+(para_FA05->OutPut) ;
	system(MV.c_str()) ;


	char * B = const_cast<char*>((chrlist).c_str());
	char * ssTmp[5]={"stat", "-InPut", A ,"-OutPut" , B } ;
	FA_stat_main(5 , ssTmp ) ;

	if  (para_FA05->GZNo)
	{
		string Gzip="gzip -d  "+(para_FA05->OutPut);
        system(Gzip.c_str());
	}

	delete para_FA05 ;
	return 0;
}

///////// swimming in the sky and flying in the sea ////////////
