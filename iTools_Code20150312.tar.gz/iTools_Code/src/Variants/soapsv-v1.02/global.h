#ifndef _GLOBAL_H_
#define _GLOBAL_H_

////////////////////////////////////////////////////////
//global.cpp
#include "include.h"
#include "common.h"
#include <string.h>
#include <uuid/uuid.h>
#include <sys/stat.h>


typedef struct _Argument
{
	string   pTag;
	string   pVal;
}Argument;
typedef vector<Argument>        VArgument;
typedef VArgument::iterator     VArgumentIT;
extern VArgument		g_vArg;

struct CheckValue
{
	CheckValue(string pTag)
	{
		m_pTag = pTag;
	}
	
	bool operator()(Argument item)
	{
		return strcmp(m_pTag.c_str(), item.pTag.c_str()) == 0;
	}
	
	string   m_pTag;
};

///////////////////  declare functions /////////////////
void 	AfxGetOptions(int, char**);
char* 	AfxGetValue(const char*);
int 	AfxGetParamCount();
bool 	Isinteger(char*, long*, int len);
void	ParseFileInfo(const char* pName, FILEINFO* fi);
void	Getuuidstring(string& str);

/*Get filenames from a file list . Identify *.l *.L *.lst *.list. If not*/
void	Getnameformlist(const char* name, vector<string>& vstr);
#define Getnamefromlist(x,y) Getnameformlist(x,y)

//Given an old filename,an output directory and a new file extension name, return a new name.
//Formatnewfilename("../temp/file.txt", ".data", "test")  return a name test/file.data .
string	Formatnewfilename(string old, string ext, const char* dir = ".");
///////////////////////////////////////////////////////
// binary search an item, then return it.
template <class _ForwardIter, class _Tp, class _Pre>
inline _ForwardIter _binary_search(_ForwardIter __first, _ForwardIter __last, const _Tp& __val, _Pre __comp) 
{
	_ForwardIter __i = __first;
	int		__h = __last - __first - 1;
	int		__l = 0; int __m;int __flag;
	while (__l <= __h)
	{
		__m = (__h + __l)/2;
		__flag = __comp(__val, *(__i + __m));
		if(__flag == 0)return (__i + __m);
		else if(__flag > 0) __l = __m + 1;
		else __h = __m - 1;
	}
	return __last;
}
//////////////////////////////////////////////////////////////////////////
VArgument		g_vArg;

void AfxGetOptions(int argc, char** argv)
{
	g_vArg.clear();
	for (int i=1; i<argc; i++)
	{
		Argument        arg;
		
		arg.pTag = string(argv[i]);
		if (arg.pTag.find("-") != 0)
			continue;
		i++;
		if(argv[i] == NULL || (argv[i]!=NULL && argv[i][0]=='-'))
		{
			arg.pVal = "";
		}
		else
		{
			arg.pVal = string(argv[i]);
		}
		string	strarg(arg.pTag);
		if (strarg[0] == strarg[1])
		{
			Argument        arg;
			arg.pTag = strarg.substr(1, strarg.length()-1);
			arg.pVal = (argv[i]==NULL) ? "" : argv[i][0]=='-' ? "" : string(argv[i]);
			g_vArg.push_back(arg);
		}
		else
		{
			Argument        arg;
			arg.pTag = strarg;
			arg.pTag.insert(0, "-");
			arg.pVal = (argv[i]==NULL) ? "" : argv[i][0]=='-' ? "" : string(argv[i]);
			g_vArg.push_back(arg);
		}
		i--;
		g_vArg.push_back(arg);
	}
}

char* AfxGetValue(const char* pTag)
{
	VArgumentIT it = find_if(g_vArg.begin(), g_vArg.end(), CheckValue(string(pTag)));
	if(it != g_vArg.end())
	{
		return ((*it).pVal.empty())? const_cast<char*>("") : (char*)(*it).pVal.c_str();
	}
	return NULL;
}

bool Isinteger(char* s, long* val, int len)
{
	if(len <= 0)
	{
		len = strlen(s);
	}
	
	char* e;
	*val = strtol(s, &e, 10);
	if(e == s+len)
		return true;
	
	return false;
}

int AfxGetParamCount()
{
	return (int)g_vArg.size();
}

void ParseFileInfo( const char* pName, FILEINFO* fi )
{
	string		str(pName);
	int			n = -1;

	if ((n=str.rfind("/")) == -1)
	{
		fi->dir = "./";
		fi->name = str;
		int pos = str.rfind(".");
		fi->ext = (pos == -1) ? "" : str.substr(pos+1, str.length() - pos -1);
	}
	else
	{
		fi->dir = str.substr(0, n);
		fi->name = str.substr(n+1, str.length()-n-1);
		int pos = str.rfind(".");
		fi->ext = (pos == -1) ? "" : str.substr(pos+1, str.length() - pos -1);
	}
}

void Getuuidstring( string& str )
{
	uuid_t		uid;
	uuid_generate(uid);
	char	inid[40];
	uuid_unparse(uid, inid);
	str = inid;
}

void Getnameformlist( const char* name, vector<string>& vstr )
{
	if (name == NULL)
	{
		cerr<<"No a *.l or *.L or *.lst or *.list file input"<<endl;
		return;
	}

	string s = name;
	string tmp = s.substr(s.rfind('.')+1, s.length()-s.rfind('.')-1);
	if (strcmp(tmp.c_str(), "l")==0 || strcmp(tmp.c_str(), "L")==0 || strcmp(tmp.c_str(), "list")==0 || strcmp(tmp.c_str(), "lst")==0 )
	{
		igzstream	ifile(name);
		if (!ifile.good())
		{
			cerr<<"Can't open file : "<<name<<endl;
			return;
		}
		string		str;
		vstr.clear();
		while (getline(ifile, str))
		{
			vstr.push_back(str);
		}
		ifile.close();
	}
	else
	{
		vstr.push_back(s);
	}
}

string Formatnewfilename( string old, string ext, const char* dir /*= "."*/ )
{
	FILEINFO	fi;
	ParseFileInfo(old.c_str(), &fi);
	string	tmp;
	if(dir == NULL)
		tmp = ".";
	else
		tmp = dir;
	mkdir(tmp.c_str(), 00755);
	
	return tmp+"/"+fi.name+ext;
}

#endif
