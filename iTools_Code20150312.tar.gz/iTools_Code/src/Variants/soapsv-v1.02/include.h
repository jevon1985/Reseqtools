#ifndef _INCLUDE_H_
#define _INCLUDE_H_

#include <vector>
#include <fstream>
#include <algorithm>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <cmath>
#include <map>
#include <iostream>
#include <dirent.h>
//Draw image header files//
#include <gd.h>
#include <gdfontl.h>
#include <gdfonts.h>
//////////////////////////
#ifdef THREAD
#include <pthread.h>
#endif
#include <sys/time.h>
#include <dlfcn.h>
#include "../../include/gzstream/gzstream.h"
//#include <boost/iostreams/filtering_stream.hpp>
//#include <boost/iostreams/filter/gzip.hpp>
//#include <boost/iostreams/device/file.hpp>
using namespace std;
//using namespace boost::iostreams;
#endif
