#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include "../include/zlib/zlib.h"
#include "../ALL/kseq.h"
#include "../ALL/comm.h"
#include "FileSF.h"
#include "FilePaste.h"
#include "FileCat.h"

using namespace std;

int File_SF_main(int argc,char *argv[]);
int Fre_main(int argc, char **argv) ;
int all_genetype_main(int argc, char **argv) ;
int Other_Merge_main(int argc,char *argv[]) ;
int Other_split_main(int argc,char *argv[] ) ;
int Alg_View_main(int argc, char *argv[]) ;
int AddRef_main(int argc, char *argv[]);
int Other_less_main(int argc, char **argv);
int File_Cat_main(int argc,char *argv[]) ;
int MFile_Paste_main(int argc,char *argv[]) ;

static int  File_usage ()
{
	cerr<<""
		"\n"
		"\tFile Tools Usage:\n\n"
		"\t\tsplit       split FILE(s) to SubFile By Row-ID\n"
		"\t\tmsort       sort all FILE(s) quick & low memory\n"
		"\t\tmerge       merge multi Sort FILE(s) to a Sort FILE\n"
		"\t\tSF          Find Same or Diff in two Files\n"
		"\t\tPaste       Paste some Row of Files into one FILE\n"
		"\t\tFre         stat Row Frequency Dis of FILE(s)\n"
		"\t\tview        view the Alignment[Bam,Sam,Soap]\n"
		"\t\tAddRef      Add the Ref base to the input files\n"
		"\t\tless        view the file like less\n"
		"\t\tcat         cat  the file like cat & zcat\n"
		"\n"        
		"\t\tHelp        Show this help\n"
		"\n";
	return 1;
}

int File_Tools_main(int argc, char *argv[])
{
	if (argc < 2) { return File_usage(); }
	else if (strcmp(argv[1], "Fre") == 0) { return Fre_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "split") == 0) { return Other_split_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "msort") == 0) { return msort_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "merge") == 0) { return Other_Merge_main(argc-1, argv+1); }
	else if (strcmp(argv[1], "Paste") == 0) { return MFile_Paste_main(argc-1, argv+1); }
	else if (strcmp(argv[1], "Alg2geno") == 0) { return all_genetype_main(argc-1, argv+1) ;}
	else if (strcmp(argv[1], "view") == 0) { return  Alg_View_main(argc-1, argv+1);}
	else if (strcmp(argv[1], "AddRef") == 0) { return AddRef_main(argc-1, argv+1);}
	else if (strcmp(argv[1], "SF") == 0) { return File_SF_main(argc-1, argv+1);}
	else if (strcmp(argv[1], "less") == 0) { return  Other_less_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "cat") == 0) { return   File_Cat_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Help") == 0  || strcmp(argv[1], "help") == 0) { File_usage(); }
	else
	{
		cerr<<"FileTools [main] unrecognized command "<<argv[1]<<endl;
		return 1;
	}
	return 0;
}

