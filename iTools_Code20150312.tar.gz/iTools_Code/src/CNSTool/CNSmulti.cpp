#include<iostream>
#include<fstream>
#include<map>
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string>
#include<time.h>
#include<float.h>
#include "glfRead.h"
#include "GLFmulti.h"
#include <iomanip>
#include "../include/gzstream/gzstream.h"
#include "../ALL/comm.h"
using namespace std ;


#ifndef DBL_MANT_DIG
#define DBL_MANT_DIG 35
#endif
//*///
#define MAX_FILE_LIST_LEN 512
#define MAX_LIST_NAME_LEN 1024
#define MAX_CHR_NAME_LEN 128

int  print_usage_5()
{
	cout <<""
		"\n"
		"\tUsage: CNSmulti -CNSList <in.cnslist> -OutPut <out.raw>\n"
		"\n"
		"\t\t-CNSList   <str>   CNS file (soapsnp) input list\n"
		"\t\t-OutPut    <str>   File name of output raw\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_cmd_5(int argc, char **argv ,  Para_5 * para_5)
{
	if (argc <=2 ) {print_usage_5();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "CNSList" )
		{
			if(i + 1 == argc) { LogLackArg( flag ) ;return 0;}
			i++;
			para_5->input_file=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg( flag ) ;return 0;}
			i++;
			para_5->output_file=argv[i];
		}
		else if (flag  == "help")
		{
			print_usage_5();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_5->input_file).empty() ||  (para_5->output_file).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}

//int CNSmulti_main(int argc,char *argv[]){
int main(int argc,char *argv[]){
	Para_5 * para_5 = new Para_5;
	if (parse_cmd_5(argc, argv, para_5 )==0)
	{
		delete para_5  ;
		return 0;
	}

	clock_t start_time,finish_time;
	double time_cost=0.0,*log10_prob=NULL,power[256]={0.0},LLR_mat[MAX_FILE_LIST_LEN][10],count[4]={0.0},copyNum=0.0,indi_G_LL=0.0;

	int i=0,j=0,k=0,N_indi=0,N_hap=0,minLLR=0,chrLen=-1,chrLen_tmp=0,LLR[10],total_depth=0,indi_dep=0,ref_index=0;
	int type=0,base=0,base1=-1,base2=-1,besttype[3],minor_count=0,est_G=0;
	char chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],ref='N',str_name[1024];
	start_time=clock();
	string outfile="a";

	vetor <string> File ;
	int File_Acount=ReadList ( para_5->input_file  , File  );
	igzstream *CNS = new igzstream[File_Acount] ;

	for (int i=0; i<File_Acount ; i++)
	{
		CNS[i].open(File[i].c_str(),ifstream::in) ;
		if  (CNS[i].good())
		{			
		}
		else
		{
			cerr<<File[i]<<"\tcan't open"<<endl ;
		}
	}

	string outfile1=(para_5->output_file)+".depth";
	ofstream out_fs(outfile1.c_str());

	para_5->output_file=add_Asuffix(para_5->output_file);
	ogzstream OUTRaw ((para_5->output_file).c_str()); // write_para_4


	map <int,int> Depth_sum ;
	map <int,map<int, int> > Depth ;

	////////////////////////swimming in the sea & flying in the sky /////////////////

	N_indi=File_Acount;
	N_hap=2*N_indi;
	minLLR=(int)(20+10*log10((double)N_hap));
	double G_LL[N_hap+1];
	memset(G_LL,0,N_hap+1);
	log10_prob=(double *)malloc(3*(N_hap+1)*sizeof(double));
	Prior_mat_gen(N_hap,log10_prob);
	Log2normal(power);
	if(MAX_FILE_LIST_LEN<N_indi){
		fprintf(stdout,"The number of files in GLFlist should not more than %d\n",MAX_FILE_LIST_LEN-1);
		return 0;
	}
	int TTTMP=N_hap-2;

	////////////////////////swimming in the sea & flying in the sky /////////////////

	while(!CNS[0].eof())
	{
		memset(count,0,4*sizeof(double));
		total_depth=0;
		copyNum=0;
		ref='N';
		long PositionCheck= 0 ;

		for (int k=0; k<File_Acount ; k++)
		{   
			string  line ;
			getline(CNS[k],line);
			if (line.length()<=0) { continue ;}

			istringstream isone (line,istringstream::in);
			string chr_id ,RST ,DB;
			char Base, Base1, Base2 ;
			int Q_A,Q_1,Q_2, UDepth_1,ADepth_1,UDepth_2,ADepth_2  ;
			double  CopyN ;
			isone>>chr_id>>Position>>ref>>Base>>Q_A>>Base1>>Q_1>>UDepth_1>>ADepth_1>>Base2>>Q_2>>UDepth_2>>ADepth_2>>indi_dep>>RST>>CopyN>>DB;
			if (PositionCheck==0)
			{
				PositionCheck=Position;
			}
			else if ( PositionCheck!=Position )
			{
				cerr<<"sample "<<k+1<<" : "<<Position<<"\t!=\t"<<PositionCheck<<endl;
				return 0;
			}
			total_depth+=indi_dep;
			Depth[k][indi_dep]++ ;

			copyNum+=(indi_dep*CopyN);


			for(type=0;type<10;type++){
				LLR_mat[k][type]=power[LLR[type]];
				if(type<4){
					count[code[type]&3]+=LLR_mat[k][type];
				}else{
					count[code[type]&3]+=LLR_mat[k][type];
					count[(code[type]>>2)&3]+=LLR_mat[k][type];
				}
			}
		}
	}


	//const char decode[16] = {'N','A','C','N','G','N','N','N','T','N','N','N','N','N','N','N'};
	//const int code[10] = {0,5,15,10,1,3,2,7,6,11};
	//const int rev_code[16] = {0,4,6,5,4,1,8,7,6,8,3,9,5,7,9,2};
	///*////



	for(j=(para_5->start);j<(para_5->end);j++){
		memset(count,0,4*sizeof(double));
		total_depth=0;
		copyNum=0;
		ref='N';
		for(k=0;k<N_indi;k++){
			ref_index=Read_base(Files[k],&indi_CN,&indi_dep,LLR);
			total_depth+=indi_dep;
			Depth[k][indi_dep]++;
			copyNum+=(indi_dep*(indi_CN+0.5));

			if('N'==ref){
				ref=decode[ref_index];
			}else{
				if(ref!=decode[ref_index]){
					fprintf(stdout,"Error,ref!=decode[ref_index]\n");
					cerr<<"sample "<<k+1<<" : "<<ref<<"\t!=\t"<<decode[ref_index]<<endl;
					return 0;
				}
			}
			for(type=0;type<10;type++){
				LLR_mat[k][type]=power[LLR[type]];
				if(type<4){
					count[code[type]&3]+=LLR_mat[k][type];
				}else{
					count[code[type]&3]+=LLR_mat[k][type];
					count[(code[type]>>2)&3]+=LLR_mat[k][type];
				}
			}
		}

		base1=-1;base2=-1;
		for(base=0;base<4;base++){
			if(base1==-1||count[base]>count[base1]){
				base2=base1;
				base1=base;
			}else if(base2==-1||count[base]>count[base2]){
				base2=base;
			}else{
			}
		}
		memset(G_LL,0,(N_hap+1)*sizeof(double));
		besttype[0]=rev_code[(base1<<2)|base1];
		besttype[1]=rev_code[(base1<<2)|base2];
		besttype[2]=rev_code[(base2<<2)|base2];
		for(minor_count=0;minor_count<N_hap;minor_count++){
			G_LL[minor_count]=0.0;
			for(k=0;k<N_indi;k++){
				indi_G_LL=0.0;
				for(type=0;type<3;type++){
					indi_G_LL+=(pow(10,*(log10_prob+minor_count*3+type))*LLR_mat[k][besttype[type]]);
				}
				G_LL[minor_count]+=log10(indi_G_LL);
			}
		}
		est_G=0;
		for(minor_count=0;minor_count<TTTMP;minor_count++){
			if((G_LL[minor_count]>G_LL[minor_count+1])&&(G_LL[minor_count+1]>G_LL[minor_count+2])){
				est_G=minor_count;
				break;
			}
		}

		if(total_depth!=0){
			copyNum/=total_depth;
		}else{
			copyNum=15;
		}
		Depth_sum[total_depth]++;
		if (total_depth!=0)
		{
			char REF="ACTG"[base1];
			char ALT="ACTG"[base2];
			int SNPQ=(int)(10*(G_LL[est_G]-G_LL[0])+0.5);
			OUTRaw<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(6)<<chrName<<"\t"<<(j+1)<<"\t"<<ref<<"\t"<<total_depth<<"\t"<<copyNum<<"\t"<<REF<<"\t"<<ALT<<"\t"<<N_hap-est_G<<"\t"<<est_G<<"\t"<<SNPQ<<endl;
		}
		else
		{
			char REF="ACTG"[base1];
			char ALT="ACTG"[base2];
			OUTRaw<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(6)<<chrName<<"\t"<<(j+1)<<"\t"<<ref<<"\t0\t15.00000\t"<<REF<<"\t"<<ALT<<"\t"<<N_hap<<"\t0\t0"<<endl;
		}
	}
	cout<<"Finished chrName: "<<chrName<<endl;
}



////////////////////////swimming in the sea & flying in the sky //////////////////

OUTRaw.close();
for (int i=0; i<File_Acount ; i++)
{
	CNS[i].close();
}

out_fs<<"#depth\tnumber"<<endl;
out_fs<<">#####Glf_sample\tAll_sample_Depth\t#########"<<endl;
map  <int,int> ::const_iterator map_it=Depth_sum.begin();

while(map_it!=Depth_sum.end())
{
	out_fs<<map_it->first<<"\t"<<map_it->second<<endl;
	map_it++;
}

map <int,map<int, int> > ::const_iterator outerit=Depth.begin();
map<int,int > ::const_iterator innerit ;


for(outerit=Depth.begin() ; outerit!=Depth.end(); outerit++)
{
	out_fs<<">#####Glf_sample\t"<<(outerit->first+1)<<"\t#########"<<endl;
	for(innerit=outerit->second.begin() ; innerit!=outerit->second.end();  innerit++)
	{
		out_fs<<innerit->first<<"\t"<<innerit->second<<endl;
	}
}
out_fs.close();
finish_time=clock();
time_cost=(double)(finish_time-start_time)/CLOCKS_PER_SEC;
cout<<"Misson complete!"<<endl;
cout<<"total time cost is: "<<time_cost<<"seconds"<<endl;
delete para_5 ;
return 1 ;
}

///////// swimming in the sky and flying in the sea ////////////
