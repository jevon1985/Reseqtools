#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <map>
//#include <hash_map>
//#include </opt/blc/gcc-4.5.0/include/c++/4.5.0/backward/hash_map> 
#include <string>
#include <ctime>
#include <algorithm>
#include "../ALL/comm.h"
#include "../include/gzstream/gzstream.h"
#include "../Soap/xam2soap/TSamCtrl.h"
#include "../Soap/xam2soap/Ttools.h"

//#include <ext/hash_map>
using namespace std ;
//using namespace __gnu_cxx;

/// ///////swimming in the sea & flying in the sky ////////////

int  print_usage_cn6()
{
	cout <<""
		"\n"
		"\tUsage: AddcnAll -InRaw <in.raw> -SoapList <SoapBychr.list> -OutPut <out.addcn>\n"
		"\n"
		"\t\t-InRaw     <str>   Input file of GLFmulti raw\n"
		"\t\t-SoapList  <str>   soap by chr list\n"
		"\t\t-BamList   <str>   bam by chr list\n"
		"\t\t-SamList   <str>   sam by chr list\n"
		"\t\t-OutPut    <str>   output addcn file with copyNumber\n"
		"\t\t-ChrLeng   <int>   The length of the chr ref\n"
		"\n"
		"\t\t-AllSite           output copyNumber for all site[NA]\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


class Para_cn6 {
	public:
		string raw ;
		string soaplist ;
		string bamlist ;
		string samlist ;
		string output ;
		long chrleng ;
		bool PringAll ;
		Para_cn6()
		{
			chrleng=0;
			raw="";
			soaplist="";
			bamlist="";
			samlist="";
			output="";
			PringAll=false ;
		}
};




int parse_cmd_cn6(int argc, char **argv, Para_cn6 * para_cn6)
{
	if (argc <=2 ) {print_usage_cn6();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");
		if (flag  == "InRaw" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_cn6->raw=argv[i];
		}
		else if (flag  ==  "SoapList")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_cn6->soaplist=(argv[i]);
		}
		else if (flag  ==  "BamList" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_cn6->bamlist=(argv[i]);
		}
		else if (flag  ==  "SamList" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_cn6->samlist=(argv[i]);
		}
		else if (flag  ==  "ChrLeng")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_cn6->chrleng=atol(argv[i]);
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_cn6->output=argv[i];
		}
		else if (flag  == "help")
		{
			print_usage_cn6();return 0;
		}
		else if (flag  == "AllSite" )
		{
			para_cn6->PringAll=true ;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}

	if  ( ((para_cn6->raw).empty()) || (  (para_cn6->soaplist).empty() && (para_cn6->bamlist).empty() &&   (para_cn6->samlist).empty() )  ||   ((para_cn6->output).empty()) )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	para_cn6->output=add_Asuffix(para_cn6->output);
	if ( (para_cn6->chrleng) < 10 )
	{
		cerr<<"chr lenth must in"<<endl;
		return 0;
	}

	return 1 ;
}

int addcn_all_main(int argc,char *argv[])
{
	Para_cn6 * para_cn6 = new Para_cn6;
	if ( parse_cmd_cn6(argc, argv ,  para_cn6 ) ==0)
	{
		delete  para_cn6 ;
		return  0;
	}
	clock_t start_time = clock();
	clock_t end_time ;

	string soaplist_file=para_cn6->soaplist;
	string raw_file=para_cn6->raw ;
	string output_file=para_cn6->output ;
	long chr_length=para_cn6->chrleng ;
	chr_length+=2 ;
	pair <int,int> temp ;
	temp=make_pair(0,0) ;
	vector <pair <int,int> > Info (chr_length,temp) ;
	igzstream  raw  (raw_file.c_str(),ifstream::in); 
	ogzstream out_fs(output_file.c_str());

	if(!raw.good())
	{
		cerr << "open RawFile error: "<<raw_file<<endl;
		return 0 ;
	}

	if(!out_fs.good())
	{
		cerr << "open RawFile error: "<<output_file<<endl;
		return 0 ;
	}

	if  (!soaplist_file.empty())
	{
		igzstream  List (soaplist_file.c_str(),ifstream::in);
		if(!List.good())
		{
			cerr << "open soap list error: "<<soaplist_file<<endl;
			return 0 ;
		}
		while(!List.eof())
		{
			string soapfile;
			getline(List,soapfile);
			if(soapfile.length() > 0 )
			{
				cout<<"SoapFile\t"<<soapfile<<endl;
				igzstream  soap (soapfile.c_str(),ifstream::in);
				string id,seq,qua,ab,zw,chr;
				int hit ,length,start;
				if(!soap.good())
				{
					cerr<<"open soap error: "<<soapfile<<endl;
					return 0 ;
				}
				while(!soap.eof())
				{
					string  line ;
					getline(soap,line);
					long position ;
					if(line.length() > 0 )     
					{
						istringstream isone (line,istringstream::in);
						isone>>id>>seq>>qua>>hit>>ab>>length>>zw>>chr>>start ;
						for (int ii=0 ; ii<length ; ii++)
						{
							position = start+ii ;  
							(Info[position].first)++;
							(Info[position].second)+=hit;
						}
					}
				}
				soap.close();
			}
		}
		List.close();
	}






	if  (!((para_cn6->bamlist).empty()))
	{
		igzstream  ListB ((para_cn6->bamlist).c_str(),ifstream::in);
		if(!ListB.good())
		{
			cerr << "open bam list error: "<<(para_cn6->bamlist)<<endl;
			return 1 ;
		}
		while(!ListB.eof())
		{
			string bamfile;
			getline(ListB,bamfile);
			if(bamfile.length() > 0 )
			{
				cerr<<"bamFile\t"<<bamfile<<endl;
				char in_mode[5] ={ 0 };
				in_mode[0]='r';in_mode[1]='b';
				TSamCtrl samhandle;
				samhandle.open(bamfile.c_str(),in_mode);
				string id,seq,qua,ab,zw,chr;
				int hit ,length,start;
				if(!samhandle.isOpened())
				{
					cerr<<"open bam error: "<<bamfile<<endl;
					return 0 ;
				}
				string line;
				while(samhandle.readline(line)!=-1)
				{
					line = Talignment_format(line);
					if(line.compare(NOUSE_ALIGNMENT)==0) continue;
					long position ;
					if(line.length() > 0 )     
					{
						istringstream isone (line,istringstream::in);
						isone>>id>>seq>>qua>>hit>>ab>>length>>zw>>chr>>start ;
						for (int ii=0 ; ii<length ; ii++)
						{
							position = start+ii ;  
							(Info[position].first)++;
							(Info[position].second)+=hit;
						}
					}
				}
				samhandle.close();
				//                soap.close();
			}
		}
		ListB.close();
	}









	if  (!((para_cn6->samlist).empty()))
	{
		igzstream  ListS ((para_cn6->samlist).c_str(),ifstream::in);
		if(!ListS.good())
		{
			cerr << "open sam list error: "<<(para_cn6->samlist)<<endl;
			return 0 ;
		}

		while(!ListS.eof())
		{
			string samfile;
			getline(ListS,samfile);
			if(!samfile.empty())
			{                
				char in_mode[5] ={ 0 };
				in_mode[0]='r';                                 
				//               cout<<"SamFileOUT\t"<<samfile<<endl;
				cerr<<"SamFile\t"<<samfile<<endl;
				//              cout<<samfile<<" SamFile open"<<endl;
				TSamCtrl samhandle;
				samhandle.open(samfile.c_str(),in_mode);
				string id,seq,qua,ab,zw,chr;
				int hit ,length,start;
				if(!samhandle.isOpened())
				{
					cerr<<"open sam error: "<<samfile<<endl;
					return  0;
				}
				string line;
				while(samhandle.readline(line)!=-1)
				{
					line = Talignment_format(line);
					if(line.compare(NOUSE_ALIGNMENT)==0) continue;
					long position ;
					if(line.length() > 0 )
					{
						istringstream isone (line,istringstream::in);
						isone>>id>>seq>>qua>>hit>>ab>>length>>zw>>chr>>start ;
						for (int ii=0 ; ii<length ; ii++)
						{
							position = start+ii ;  
							(Info[position].first)++;
							(Info[position].second)+=hit;
						}
					}
				}
				//               cout<<"SamFileBB"<<endl;
				samhandle.close();
				//               cout<<"SamFileBB"<<endl;
			}
			//             cout<<"SamFileCF"<<endl;
		}
		ListS.close();
	}

	// chr31   3003853 T       57      0.101521        T       G       27      3     20 //
	while(!raw.eof())
	{
		string  line ;
		getline(raw,line);
		if(line.length() > 0 ) 
		{
			string chr ; 
			long posi ;
			istringstream isone(line,istringstream::in);
			isone>>chr>>posi ;
			if (Info[posi].first!=0)
			{
				double mean_hit=(double(Info[posi].second+0.0)/double(Info[posi].first+0.0));
				out_fs<<line<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<mean_hit<<endl;
			}
			else
			{
				out_fs<<line<<"\t25.00"<<endl;
			}
		}
	}
	raw.close();
	out_fs.close();

	if ((para_cn6->PringAll))
	{
		string output_fileAll=output_file+".all.gz";
		ogzstream OUT(output_fileAll.c_str());
		if(!OUT.good())
		{
			cerr << "open output all error: "<<(output_fileAll)<<endl;
			return  0 ;
		}
		long end=chr_length-1;
		for (long ii=1 ; ii<end ; ii++ )
		{
			if (Info[ii].first!=0)
			{
				double mean_hit=(double(Info[ii].second+0.0)/double(Info[ii].first+0.0));
				OUT<<ii<<"\t"<<(Info[ii].first)<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<mean_hit<<endl;
			}
			else
			{
				OUT<<ii<<"\tNA\tNA"<<endl;
			}
		}
		OUT.close();
	}

	end_time = clock();
	delete para_cn6 ;
	cout << "time elapsed : " << (end_time - start_time) / (float)CLOCKS_PER_SEC << endl;
	return 1 ;

}


////////////////////////swimming in the sea & flying in the sky //////////////////



////////////////////////swimming in the sea & flying in the sky //////////////////
///////// swimming in the sky and flying in the sea ////////////
