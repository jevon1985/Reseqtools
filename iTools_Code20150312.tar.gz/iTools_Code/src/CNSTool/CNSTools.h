#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include "DepthCNS.h"
#include "Glf2Depth.h"
#include "snpFilter.h"
#include "snpExtract.h"
#include "GLFmulti.h"
#include "Addcn_All_V2.2.h"
#include "Filter_Addcn.h"
#include "GLF2GPF.h"
#include "DepthRaw.h"
#include "maf.h"
#include "add_ref.h"
#include "../Other/fre.h"
#include "Glf2Geno.h"
#include "filter_genotype.h"
#include "Addcn_Bam.h"
#include "extract.h"


using namespace std;

int Filter_genotype_main(int argc, char *argv[]);
int depthcns_main(int argc, char *argv[]);
int depthraw_main(int argc, char *argv[]);
int depthglf_main(int argc, char *argv[]);
int filter_main(int argc, char *argv[]);
int extract_main(int argc, char *argv[]);
int GLFmulti_main(int argc, char *argv[]);
int FilterAddcn_main(int argc, char **argv) ;
int Addcn_main(int argc,char *argv[]) ;
int GLF2GPF_main(int argc,char *argv[]);
int Maf_main(int argc,char *argv[]);
int Fre_main(int argc, char **argv) ;
int AddRef_main(int argc, char *argv[]) ;
int Glf2Geno_main(int argc,char *argv[]) ;
int addcn_all_main(int argc,char *argv[]) ;
int EX_main(int argc, char *argv[]) ;

static int  CNSusage ()
{
    cerr <<""
        "Program: CNStools (Tools for SoapSNP output)\n"
        "Version: 0.10\thewm@genomics.org.cn\t2011-12-12\n"
        "\tIndividual Usage:\n\n"
        "\t\tExtractCns  Extract the potential snp from the cns file\n"
        "\t\tFilterCns   Filter the potential snp to get accurate SNP\n"
        "\n"
        "\tPopulation Usage:\n\n"
        "\t\tGLFmulti    Merge Glf(1.02) list to RawFile of Population\n"
        "\t\tAddcn       Add the copyNumber for the RawFile\n"
        "\t\tFilterRaw   Filter Raw(+cp)[Addcn] file to get accurate Pop SNP\n"
        "\t\tGLF2GPF     Get the genotype from the glf List by Site\n"
        "\t\tGLF2Geno    Get the genotype from the glf List by Region\n"
        "\t\tFilterGeno  Filter genotype file to get accurate genotype SNP\n"
        "\t\tMAF         Stat Minor Allele Frequency in Raw or Addcn\n"
        "\n"        
        "\tTools Usage:\n\n"
        "\t\tFre         Stat Row Frequency Distribution of file(List)\n"
        "\t\tAddRef      Add the Ref base to the input files\n"
        "\t\tExtract     Extract Site info from big File\n"
        "\t\tAddcnAll    Add the copybernum for the RawFile\n"
        "\t\tDepthGlf    Stat the allele Depth distribution in glf(1.02)\n"
        "\t\tDepthCns    Stat the allele Depth Distribution in CNS\n"
        "\t\tDepthRaw    Stat allele Depth Distribution in Raw or Addcn\n"
        "\n"        
        "\t\tHelp        Show this help\n"
        "\n";
    return 1;
}

int CNS_Tools_main(int argc, char *argv[])
{
    if (argc < 2) { return CNSusage(); }
    else if (strcmp(argv[1], "FilterCns") == 0) { return filter_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "ExtractCns")== 0) { return extract_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "DepthCns") == 0) { return depthcns_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "DepthGlf") == 0) { return depthglf_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "GLFmulti") == 0) { return GLFmulti_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Addcn") == 0) { return Addcn_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "FilterRaw") == 0) {return FilterAddcn_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "GLF2GPF") == 0) { return  GLF2GPF_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "DepthRaw") == 0) { return depthraw_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "MAF") == 0) { return Maf_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Fre") == 0) { return Fre_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "AddRef") == 0) { return AddRef_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "GLF2Geno") == 0) { return Glf2Geno_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "FilterGeno") == 0){return Filter_genotype_main(argc-1,argv+1);}
    else if (strcmp(argv[1], "Extract") == 0){return  EX_main(argc-1,argv+1);}
    else if (strcmp(argv[1], "AddcnAll") == 0){return addcn_all_main(argc-1,argv+1);}    
    else if (strcmp(argv[1], "Help") == 0)  {  CNSusage(); }
    else
    {
        cerr<<"CNSTools[main] unrecognized command "<<argv[1]<<endl;
        return 1;
    }
    return 0;	
}


