#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include "../include/zlib/zlib.h"
#include "../ALL/kseq.h"
#include "../ALL/comm.h"
#include "../FaDeal/RefGetCDS.h"
#include "Gff_CDSSNPV3.h"
#include "Gff_ano.h"
#include "Gff_Merge.h"
#include "Gff_GenePoly.h"


using namespace std;

int FA_GetCDS_main(int argc, char *argv[]) ;
int Gff_CDSSNP_main(int argc, char *argv[]) ;
int Gff_SNPAno_main(int argc, char *argv[]) ;
int Gff_GenePoly_main(int argc, char *argv[]) ;
int Gff_Merge_main(int argc, char *argv[]) ;

static int  Gff_usage ()
{
	cerr<<""
		"\n"
		"\tGff Tools Usage:\n\n"
		"\t\tgetCdsPep     Get CDS & Pep Seq  based gffFile of genome\n"
		"\t\tVarType       SNP mutation type [synonymous or not ...]\n"
		"\t\tAnoVar        Annotation Variations & give Info\n"
		"\t\tGenePoly      Stat the Gene Polymorphism(Pi TajimaD..)\n"
		"\t\tChangGff      Chang old Gff 2 new Gff by the MerList File\n"
		"\n"
		"\t\tHelp          Show this help\n"
		"\n";
	return 1;
}

int Gff_Tools_main(int argc, char *argv[])
{
	if (argc < 2) { return Gff_usage(); }
	else if (strcmp(argv[1], "getCdsPep") == 0) { return FA_GetCDS_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "VarType") == 0) { return Gff_CDSSNP_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "AnoVar") == 0) { return Gff_SNPAno_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "GenePoly") == 0) { return Gff_GenePoly_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "ChangGff") == 0) { return Gff_Merge_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Help") == 0  || strcmp(argv[1], "help") == 0) { Gff_usage(); }
	else if (strcmp(argv[1], "CDSSNP") == 0) { return Gff_CDSSNP_main(argc-1, argv+1) ; }
	else
	{
		cerr<<"GffTools [main] unrecognized command "<<argv[1]<<endl;
		return 1;
	}
	return 0;
}

