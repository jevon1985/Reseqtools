#ifndef RefGffGenePoly_H_
#define RefGffGenePoly_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"

using namespace std ;
typedef long long  llong ;

class Para_GenePoly{
	public:
		string SNP ;
		string Raw ;
		string Gff ;
		string Ref ;
		string OutPut ;
		int Window ;
		double Slide ;
		double CutOff ;
		double CpNumber ;
		int MinDepth ;
		int MaxDepth ;
		Para_GenePoly ()
		{
			SNP=""; Raw=""; Gff=""; Ref=""; OutPut="";
			Window=50000; Slide=0.1 ; CutOff=0.4 ;
			CpNumber=1.5 ;
			MinDepth=68; MaxDepth =1168 ;
		}    
};

int  Gff_GenePoly_help()
{
	cout <<""
		"\n"
		"\tUsage:GenePoly -Ref <chr#.fa> -SNP <Chr#.snp> -OutPut <gene#.info> -Raw <chr#.raw> -Gff <in.gff>\n"
		"\n"
		"\t\t-SNP        <str>   InPut Chr SNP File raw Format\n"
		"\t\t-Raw        <str>   InPut the Raw File with copynumber\n"
		"\t\t-Ref        <str>   InPut Chr Ref fa File\n"
		"\t\t-OutPut     <str>   OutPut after annotation SNP\n"
		"\n"
		"\t\t-Gff        <str>   InPut Ref gff for give out gene info\n"
		"\t\t-Window     <int>   size of sliding windows[50000]\n"
		"\t\t-Slide    <float>   Sliding X of windows[0.1]\n"
		"\t\t-CutOff   <float>   Cutoff eff-length low X of win-Length[0.4]\n"
		"\t\t-CpNumber <float>   Copynumber for effective sites[1.5]\n"
		"\t\t-MinDepth   <int>   Lowest depth for effective sites[68]\n"
		"\t\t-MaxDepth   <int>   Hightest depth for effective sites[1168]\n"
		"\t\t-help               show this help\n"
		"\n";
	return 1;
}

int Gff_GenePoly_help01(int argc, char **argv , Para_GenePoly * paraFA04)
{
	if (argc <=2 ) {Gff_GenePoly_help();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i];
		flag=replace_all(flag,"-","");

		if (flag  == "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->OutPut=argv[i];
		}
		else if (flag  ==  "SNP")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->SNP=argv[i];
		}
		else if (flag  ==  "Gff")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->Gff=argv[i];
		}
		else if (flag  ==  "Raw")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->Raw=argv[i];
		}
		else if (flag  ==  "Ref")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->Ref=argv[i];
		}
		else if (flag  ==  "Window")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->Window=atoi(argv[i]);
		}
		else if (flag  ==  "Slide")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->Slide=atof(argv[i]);
			if ( paraFA04->Slide <0 ||  paraFA04->Slide>1) 
			{
				cerr<<"Slide Para input wrong\t"<<paraFA04->Slide<<endl;
				return 0 ;
			}
		}
		else if (flag  ==  "CutOff")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->CutOff=atof(argv[i]);
			if ( paraFA04->CutOff<0 ||  paraFA04->CutOff>1) 
			{
				cerr<<"Slide Para input wrong\t"<<paraFA04->CutOff<<endl;
				return 0 ;
			}
		}
		else if (flag  ==  "CpNumber")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->CutOff=atof(argv[i]);
		}
		else if (flag  ==  "MinDepth")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->MinDepth=atoi(argv[i]);
		}
		else if (flag  ==  "MaxDepth")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->MaxDepth=atoi(argv[i]);
		}
		else if (flag  == "help")
		{
			Gff_GenePoly_help();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA04->OutPut).empty() || (paraFA04->SNP).empty() ||  (paraFA04->Ref).empty() ||  (paraFA04->Raw).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(paraFA04->OutPut)=add_Asuffix ( (paraFA04->OutPut) );

	return 1 ;
}

double Cal_pi ( int aSed ,int aMax)
{
	int c2=(aSed+aMax)*(aSed+aMax-1);
	if(c2==0) {return 0;}
	double pi=((aSed*aMax)*2.0)/c2;
	return pi;
}


double Cal_tajima( int SampleNum , double theta_Sum_pi, int SNP_Num , double & theta_W  )
{
	double a1c=0, a2c=0;
	theta_W=0;
	if(SNP_Num==0 || SampleNum==0 ){ return 0.0 ;}
	for (int i=1; i<SampleNum;i++)  // i=1..(SampleNum-1)
	{ 
		a1c+=1.0/i;
		a2c+=1.0/(i*i);
	}
	double b1c=(SampleNum+1.0)/(3.0*(SampleNum-1));
	double b2c=2.0*(SampleNum*SampleNum+SampleNum+3)/(9.0*SampleNum*(SampleNum-1));
	double c1c=b1c-(1.0/a1c);
	double c2c=b2c-((SampleNum+2.0)/(a1c*SampleNum))+a2c/(a1c*a1c);
	double e1c=c1c/a1c;
	double e2c=c2c/(a1c*a1c+a2c);
	theta_W=SNP_Num*1.0/a1c;
	double Dc=(theta_Sum_pi-theta_W)/(sqrt(e1c*SNP_Num+e2c*SNP_Num*(SNP_Num-1)));
	return Dc;
}

int Gff_GenePoly_main(int argc, char *argv[])
	//  int main(int argc, char *argv[])
{
	Para_GenePoly *paraFA04 = new Para_GenePoly;
	if( Gff_GenePoly_help01(argc, argv, paraFA04 )==0)
	{
		delete  paraFA04 ;
		return 0 ;
	}

	igzstream FileSNP ((paraFA04->SNP).c_str(),ifstream::in);
	if (FileSNP.fail())
	{
		cerr << "open SNP File error: "<<(paraFA04->SNP)<<endl;
		delete  paraFA04 ; return  0;
	}

	igzstream FileRAW ((paraFA04->Raw).c_str(),ifstream::in);
	if (FileRAW.fail())
	{
		cerr << "open SNP File error: "<<(paraFA04->Raw)<<endl;
		delete  paraFA04 ; return  0;
	}

	ogzstream OUT (((paraFA04->OutPut)).c_str());

	if(OUT.fail())
	{
		cerr << "open OUT File error: "<<(paraFA04->OutPut)<<endl;
		delete  paraFA04 ; return  0;
	}

	gzFile fp ;
	kseq_t *seq ;
	fp = gzopen((paraFA04->Ref).c_str(), "r");
	seq = kseq_init(fp);
	int l=0 ;
	string CHR ;
	ubit64_t length_chr ;
	while ((l = kseq_read(seq)) >= 0)
	{
		CHR=seq->name.s;
		length_chr=ubit64_t(seq->seq.l);
	}
	kseq_destroy(seq);
	gzclose(fp);
	int SplitNum=int(1.0/(paraFA04->Slide));
	int bin=int((paraFA04->Window)*(paraFA04->Slide));
	long Sildeing=long(length_chr/bin)+1;
	//    vector <pair <int,int> > Info (chr_length,temp);
	vector <double> MapPi (Sildeing,0.0);
	vector <long> MapSNP (Sildeing,0);
	vector <long> MapEff (Sildeing,0);

	string  lineA ;
	getline (FileSNP,lineA);
	vector<string> inf;
	split(lineA,inf," \t");

	int SampleNum=atoi(inf[7].c_str())+atoi(inf[8].c_str());
	if ( SampleNum<2 || SampleNum>99999 )
	{
		cerr<<"SNP Input Format wrong"<<endl;
		delete  paraFA04 ; return 0;
	}
	cout<<"chromosome number is "<<SampleNum<<endl;
	FileSNP.close();
	FileSNP.clear();
	igzstream SEDSNP ((paraFA04->SNP).c_str(),ifstream::in);
	while(!SEDSNP.eof())
	{
		string  line ;
		getline(SEDSNP,line);
		if (line.length()<=0)  { continue ;}
		vector<string> infTmp;
		split(line,infTmp," \t");
		if (infTmp[0] !=CHR ) { continue ;}
		long key=long(atol(infTmp[1].c_str())/bin);
		int MAX=atoi(infTmp[7].c_str());
		int SED=atoi(infTmp[8].c_str());
		double SitePi=Cal_pi(MAX,SED);
		MapPi[key]+=SitePi ;
		if (SitePi>0.00)
		{
			MapSNP[key]++;
		}
	}
	SEDSNP.close();

	int depth=0,fre_base1=0,fre_base2=0,SNP_Q;
	ubit64_t position=0;
	string chrRaw="",base1="",base2="",ref_base="";
	double cp_log=0.0;

	while(!FileRAW.eof())
	{
		string  line ;
		int position ;
		getline(FileRAW,line);
		if (line.length()<=0)  { continue  ; }
		double  mean_hit=1.0;
		istringstream isone (line,istringstream::in);
		isone>>chrRaw>>position>>ref_base>>depth>>cp_log>>base1>>base2>>fre_base1>>fre_base2>>SNP_Q>>mean_hit ;
		if ( depth < (paraFA04->MinDepth) || depth > (paraFA04->MaxDepth) ) { continue  ; }
		if ( mean_hit<0 || mean_hit > (paraFA04->CpNumber) ) { continue  ; }
		long key=long(position/bin);
		MapEff[key]++;
	}


	if ((paraFA04->Gff).empty())
	{
		OUT<<"#Region\tTheta_Pi\tTheta_W\tTajima'D\tSNP_Num\tEffective_Site"<<endl;
		for (int i=0 ; i<Sildeing; i++ )
		{
			long TotalEff=0;
			long TotalLen=0;
			double TotalPi=0.0;
			int  TotalSNP=0;
			ubit64_t START=i*bin;
			for (long j=0 ; j<SplitNum && (i+j)<Sildeing ; j++)
			{
				long key=i+j;
				TotalEff+=MapEff[key] ;
				TotalSNP+=MapSNP[key] ;
				TotalPi+=MapPi[key] ;
				TotalLen+=bin ;
			}
			ubit64_t END=START+TotalLen;
			START++;
			int AtLessLength=int(TotalLen*(paraFA04->CutOff));
			if (TotalEff<AtLessLength)
			{
				OUT<<START<<"-"<<END<<"\tNA\tNA\tNA\t"<<TotalSNP<<"\t"<<TotalEff<<endl;
				continue  ;
			}
			else
			{
				double theta_Sum_W=0.0;
				double TajimaD= Cal_tajima(SampleNum,TotalPi,TotalSNP,theta_Sum_W );
				OUT<<START<<"-"<<END<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(6)<<TotalPi/TotalEff<<"\t"<<theta_Sum_W/TotalEff<<"\t"<<TajimaD<<"\t"<<TotalSNP<<"\t"<<TotalEff<<endl;
			}
		}
	}
	else
	{
		igzstream  FileGFF ((paraFA04->Gff).c_str(),ifstream::in);
		map <string,pair <llong,llong> >   GeneList ;
		if(!FileGFF.good())
		{
			cerr << "open InputFile error: "<<(paraFA04->Gff)<<endl;
			delete  paraFA04 ; return 0;
		}
		while(!FileGFF.eof())
		{
			string  line ;
			getline(FileGFF,line);
			if (line.length()<=0 || line[0] == '#' )  { continue  ; }
			istringstream isone (line,istringstream::in);
			string chr , flag , CDS , ZhengFu ,geneID ;
			llong Start,End ;
			isone>>chr>>flag>>CDS ;

			if ( CDS  == "CDS"  || CDS == "chromosome" || CDS.find("UTR")!=string::npos || CDS.find("intron")!=string::npos )
			{
				continue ; 
			}

			if ( CDS == "gene"  || CDS == "mRNA" )
			{
				isone>>Start>>End>>flag>>ZhengFu>>flag>>geneID ;
				vector<string> inf;
				vector<string> Temp;
				split(geneID,inf,";");
				split(inf[0],Temp,"=");
				string GeneID= Temp[Temp.size()-1] ;
				pair <llong,llong>  Region=make_pair(Start,End) ;
				GeneList.insert(map <string,pair <llong,llong> >:: value_type(GeneID,Region));
			}
		}    
		FileGFF.close();

		map <string,pair <llong,llong> > :: iterator it ;
		OUT<<"#Region\tTheta_Pi\tTheta_W\tTajima'D\tSNP_Num\tEffective_Site\tGeneIn"<<endl;
		for (int i=0 ; i<Sildeing; i++)
		{
			long TotalEff=0;
			long TotalLen=0;
			double TotalPi=0.0;
			int  TotalSNP=0;
			ubit64_t START=i*bin;
			for (long j=0 ; j<SplitNum && (i+j)<Sildeing ; j++)
			{
				long key=i+j;
				TotalEff+=MapEff[key] ;
				TotalSNP+=MapSNP[key] ;
				TotalPi+=MapPi[key] ;
				TotalLen+=bin ;
			}
			ubit64_t END=START+TotalLen;
			START++;
			int AtLessLength=int(TotalLen*(paraFA04->CutOff));

			if (TotalEff<AtLessLength)
			{
				OUT<<START<<"-"<<END<<"\tNA\tNA\tNA\t"<<TotalSNP<<"\t"<<TotalEff<<"\tNA"<<endl;
				continue  ;
			}
			else
			{
				string GeneIN="";
				for (it=GeneList.begin(); it!=GeneList.end(); it++ )
				{
					if (((it->second).first >= START )  &&  ( (it->second).second <= END  ) )
					{
						GeneIN+=(it->first)+"#";
					}
				}
				double theta_Sum_W=0.0;
				double TajimaD= Cal_tajima(SampleNum,TotalPi,TotalSNP ,theta_Sum_W );
				OUT<<START<<"-"<<END<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(6)<<TotalPi/TotalEff<<"\t"<<theta_Sum_W/TotalEff<<"\t"<<TajimaD<<"\t"<<TotalSNP<<"\t"<<TotalEff<<"\t"<<GeneIN<<endl;
			}
		}
	}



	OUT.close();
	delete paraFA04 ;
	return 0;
}
#endif // RefGffGenePoly_H_ //
///////// swimming in the sky and flying in the sea ////////////

