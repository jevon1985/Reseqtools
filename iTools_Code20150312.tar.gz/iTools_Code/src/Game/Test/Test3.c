/* 
 * File:   newmain.cc
 * Author: Null
 * Blog: http://hi.baidu.com/hetaoos
 * Created on 2008��7��30��, ����12:49
 */


#include "pthread.h"
#include <stdio.h>
char A[100] ;
int B  ;

static void * run(void * id)
{
	printf("TH run\n");
	char a=getchar();
	while(1)    
	{
		printf("TH run\n");
		char a=getchar();
		B++ ;
		if (B>100){B=99;}
		if (a=='q' || a=='Q') {return NULL  ;}
		A[B]=a; 
		sleep(1);
	}
	return NULL ;
}

void *  dd(void * null )
{
	while(1)
	{
		B--;
		if (B<0)
		{
			B=0;
			A[0]='c';
		}

		sleep(2);
	}

}

int main(int argc, char** argv)
{
	B=0;
	A[0]='c';
	pthread_t tid; 
	int t =0 ;
	pthread_attr_t attr; 
	if(pthread_create(&tid, NULL, run, NULL )==0)
	{
		printf("TH heweiming\n");
	}
	pthread_join(tid,NULL);
	//pthread_create(&threads[1], NULL, dd, NULL);
	printf("TH heweiming\n");
	return 0 ;
}


