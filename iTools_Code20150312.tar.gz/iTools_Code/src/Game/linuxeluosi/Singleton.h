#ifndef BERT_SINGLETON_H
#define BERT_SINGLETON_H

template <typename T>
class Singleton
{
	protected:
		Singleton() {}
		~Singleton() {}

		static T * sm_Instance;

	public:
		static T * Instance()
		{
			return sm_Instance;
		}

		static void DelInstance()
		{
			delete sm_Instance;
			sm_Instance = NULL;
		}
};

template <typename T>
T * Singleton<T>::sm_Instance= new T;

#endif
