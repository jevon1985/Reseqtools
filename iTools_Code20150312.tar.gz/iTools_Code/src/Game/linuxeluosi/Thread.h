#ifndef BERT_THREAD_H
#define BERT_THREAD_H

#include <pthread.h>

class Runnable
{
	public:
		virtual ~Runnable() { }

		virtual void Run() = 0;
};

class Thread: public Runnable
{
	// 本线程ID
	pthread_t m_tid;
	// 是否在运行的标志
	bool m_running;
	//线程函数，内部调用run
	static void * _ThreadFunc(void * );

	public:
	Thread();
	// 睡眠 秒
	static unsigned int Sleep( unsigned int seconds);
	// 睡眠毫秒
	static unsigned int MSleep( unsigned int mSeconds);
	// 启动线程
	bool Start() ;
	// 等待本线程运行完
	void Join() const;
	//是否在运行
	bool IsAlive() const { return m_running; }
	// 终止线程运行
	void Stop()          { m_running = false; }
};

#endif

