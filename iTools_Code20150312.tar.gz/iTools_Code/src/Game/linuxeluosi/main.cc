#include <memory>
#include <cstdio>
#include "Tetris.h"
#include "TtyAuto.h"
#include <iostream>
#include <fstream>
using namespace std;

static void Instruction()
{
	// 一些说明性文字
	printf("\033[2J");
	printf("\033[4;34;47m%s\033[0m", "\t\t\tYou can use the key 'A','S','D','W' to control the block.\n\n\t\t\tPress space key make the block down to bottom.\n\n\t\t\t'P' to pause the game.\n\n");
	printf("\033[5;34;41m%s\033[0m", "\t\t\tPRESS ANY KEY TO START GAME...\n\n" );
	getchar();
}
int main(int ac, char *av[])
{
	std::auto_ptr<TtyAuto> autoAdjustTty(TtyAuto::Instance());

	//	Instruction();

	// 游戏开始
	Tetris game;
	game.Start();
	game.Join();
	game.Stop();     
	system("clear") ;
	//autoAdjustTty->DelInstance();
	//    autoAdjustTty.DelInstance();
	printf("\t\tGame Over\n");
	printf("\t\tLove hewm\n");
	return 0;
}
