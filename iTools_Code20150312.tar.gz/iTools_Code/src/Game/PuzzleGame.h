#ifndef  PuzzleGame_H_
#define  PuzzleGame_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include <ncurses.h>
#include <ctime>
#include "LiangLianKan.h"
#include "../ALL/comm.h"
#include "Draw_comm.h"

#include "FindMine.h"


///////////////////

bool Puzzle_tv_Draw (FindMine * tv )
{
	clear(); 
	int attr=0;
	attr |= COLOR_PAIR(7); attron(attr);
	mvaddstr(0,(tv->mcol/2)-15,"Welcome come, Puzzle Game");
	int HelpPosi=(tv->mcol)/2 ;
	mvaddstr(1,(tv->mcol/2)-15,"Love hewm@genomics.org.cn");
	mvaddstr(2,(tv->mcol/2)-15,"Make digit InOrder by using mouse");
	mvaddstr(3,(tv->mcol/2)-25,"q : leave; n : next level; f :forward level; r : repeat" );
	string sore="level :" + Int2Str(tv->level);
	mvaddstr(4,(tv->mcol/2)-10,sore.c_str());
	attroff(attr);
	attr = COLOR_PAIR(4);
	attron(attr);
	board(stdscr, tv->STARTY, tv->STARTX,  tv->ROW,  tv->COL, tv->WIDTH, tv->HEIGHT);
	attroff(attr);
	refresh();
	return true ;
}

bool Puzzle_check (  FindMine * tv  )
{
	int Rignt_count=0;
	for (int i = 0; i <(tv->COL); i++)
	{
		for (int j = 0; j <(tv->ROW); j++)
		{
			int Pvalue=j*(tv->ROW)+i+1;
			if ((tv->Arry[i][j].Find)==Pvalue)
			{
				Rignt_count++;
			}
		}
	}
	Rignt_count++;
	if (Rignt_count==(tv->Count))
	{
		return true ;
	}
	else
	{
		return false ;
	}
}


bool Puzzle_tv_Pair( FindMine * tv )
{
	int endy = tv->STARTY + tv->ROW * tv->HEIGHT;
	int endx = tv->STARTX + tv->COL * tv->WIDTH;
	int deltay = tv->HEIGHT / 2;
	int deltax = tv->WIDTH  / 2;
	MEVENT event;
	int x1=0 ,y1=0 ;
	int Right=0;
	int Flag=(tv->Count) ;
	refresh();
	while(true)
	{        

		if (Puzzle_check(tv))
		{
			return true ;
		}

		int  ch = getch();
		if(ch == KEY_MOUSE && (getmouse(&event) == OK ))
		{
			int x=(event.x- tv->STARTX)/(tv->WIDTH);
			int y=(event.y- tv->STARTY)/(tv->HEIGHT);

			if ( ( event.bstate & BUTTON1_PRESSED) )
			{
				if ( (-1<x && x<(tv->COL) ) && (-1<y && y<(tv->ROW) ))
				{        
					int NowX0=x , NowX1=x-1, NowX2=x+1;
					int NowY0=y,  NowY1=y-1, NowY2=y+1;
					int  attr = COLOR_PAIR(5) ;
					attron(attr);
					if ( (tv->Arry[x][y]).Find!=0)
					{
						if ( (NowY1>-1 && NowY1<(tv->ROW)) && ((tv->Arry[NowX0][NowY1]).Find==0) )
						{                           
							mvprintw(tv->STARTY+NowY1*tv->HEIGHT+deltay,tv->STARTX+NowX0*tv->WIDTH+deltax, "%d", (tv->Arry[x][y]).Find);
							mvaddstr(tv->STARTY+y*tv->HEIGHT+deltay,tv->STARTX+x*tv->WIDTH+deltax,"  ");
							Swap((tv->Arry[x][y]).Find , (tv->Arry[NowX0][NowY1]).Find );
						}
						else if ( (NowY2>-1 && NowY2<(tv->ROW)) && ((tv->Arry[NowX0][NowY2]).Find==0) )
						{
							mvprintw(tv->STARTY+NowY2*tv->HEIGHT+deltay,tv->STARTX+NowX0*tv->WIDTH+deltax, "%d", (tv->Arry[x][y]).Find);
							mvaddstr(tv->STARTY+y*tv->HEIGHT+deltay,tv->STARTX+x*tv->WIDTH+deltax,"  ");

							Swap((tv->Arry[x][y]).Find , (tv->Arry[NowX0][NowY2]).Find );
						}
						else if ( (NowX1>-1 && NowX1<(tv->ROW)) && ((tv->Arry[NowX1][NowY0]).Find==0) )
						{
							mvprintw(tv->STARTY+NowY0*tv->HEIGHT+deltay,tv->STARTX+NowX1*tv->WIDTH+deltax, "%d", (tv->Arry[x][y]).Find);
							mvaddstr(tv->STARTY+y*tv->HEIGHT+deltay,tv->STARTX+x*tv->WIDTH+deltax,"  ");
							Swap((tv->Arry[x][y]).Find , (tv->Arry[NowX1][NowY0]).Find );
						}
						else if ( (NowX2>-1 && NowX2<(tv->ROW)) && ((tv->Arry[NowX2][NowY0]).Find==0) )
						{
							mvprintw(tv->STARTY+NowY0*tv->HEIGHT+deltay,tv->STARTX+NowX2*tv->WIDTH+deltax, "%d", (tv->Arry[x][y]).Find);
							mvaddstr(tv->STARTY+y*tv->HEIGHT+deltay,tv->STARTX+x*tv->WIDTH+deltax,"  ");
							Swap((tv->Arry[x][y]).Find , (tv->Arry[NowX2][NowY0]).Find );
						}
					}
					refresh();
					attroff(attr);
				}
			}
		}
		else if (ch == 'q')
		{
			return false ;
			break ;
		}
		else if (ch == 'n')
		{
			return true ;
		}
		else if (ch == 'r')
		{
			tv->level--;
			return true ;
		}    
		else if  (ch == 'f')
		{
			tv->level-=2 ;
			if (tv->level<0)
			{
				tv->level=0;
			}
			return true ;
		}
	}
	return true ;
}

int Puzzle_tv_Run (FindMine * tv )
{

	while(true)
	{
		tv->ROW= tv->level+2;
		tv->COL= tv->ROW ;
		(tv->Count)=(tv->ROW)*(tv->COL) ;
		tv->WIDTH=6 ;
		tv->HEIGHT=4;
		if (tv->level>6)
		{
			tv->WIDTH=5;
			tv->HEIGHT=3;
		}
		int    deltay = tv->HEIGHT / 2;
		int    deltax = tv->WIDTH  / 2;        
		tv->STARTY = (tv->mrow - tv->ROW * tv->HEIGHT) / 2 ;
		tv->STARTX = (tv->mcol - tv->COL * tv->WIDTH) / 2 ;

		tv->Arry = new Mine *[(tv->COL)];
		tv->Arry[0] = new Mine[tv->Count];

		for(int i = 1; i <(tv->COL); i++)
		{
			tv->Arry[i] = tv->Arry[i-1]+(tv->ROW);
		}

		srand((unsigned)time(NULL));

		map <int ,bool> DD;


		Puzzle_tv_Draw(tv);

		int  attr = COLOR_PAIR(5) ;
		attron(attr);

		for (int i = 0; i <(tv->COL); i++)
		{
			for (int j = 0; j <(tv->ROW); j++)
			{
				while(true)
				{
					int Pvalue=rand()%(tv->Count);
					if (DD.find(Pvalue)==DD.end())
					{
						DD[Pvalue]=true ; 
						(tv->Arry[i][j].Find)=Pvalue;
						if (Pvalue!=0)
						{
							mvprintw(tv->STARTY+j*tv->HEIGHT+deltay,tv->STARTX+i*tv->WIDTH+deltax, "%d",Pvalue); 
						}
						break ;
					}
				}
			}
		}
		attroff(attr);
		refresh();

		time_t start_time = time(NULL);
		if (Puzzle_tv_Pair(tv))
		{
			tv->level++;
			delete []  tv->Arry[0] ;
			delete []  tv->Arry ;

			time_t end_time=time(NULL);
			int Time=int(end_time - start_time);
			string time="Used Time : "+Int2Str(Time);
			mvaddstr(tv->mrow/2-2,tv->mcol/2,time.c_str());
			mvaddstr(tv->mrow/2,tv->mcol/2,"AnyKey Continue");
			getch();
			getch();
			refresh();
			beep(); 
			flash();
		}
		else
		{
			delete []  tv->Arry[0] ;
			delete []  tv->Arry ;    
			int B=COLOR_PAIR(6); attron(B);
			mvaddstr(tv->mrow/2,tv->mcol/2,"Puzzle Game Over");
			mvaddstr(tv->mrow/2+2,tv->mcol/2,"Enter 'y' : Repeat");
			mvaddstr(tv->mrow/2+4,tv->mcol/2,"Enter 'q' : Leave");
			mvaddstr(tv->mrow/2+6,tv->mcol/2,"Welcome Again");
			mvaddstr(tv->mrow/2+8,tv->mcol/2,"hewm@genomics.org.cn");
			attroff(B);
			refresh();
			return 1 ;
		}
	}
	return 1;
}


int Game_Puzzle_main(int argc, char** argv)
	//int main(int argc, char** argv)
{
	bool Game_Repeat=true ;
	int level=1;
	while(true)
	{
		FindMine  *game=new FindMine ;
		FindMine_tv_Init(game) ;
		game->level=level;
		Puzzle_tv_Run(game);
		level=game->level;
		while(true)
		{
			int c=getch();
			if (c=='Y' || c=='y' || c==32)
			{
				Game_Repeat=false ;
				break ;
			}
			else if( c=='n' || c=='N' || c=='q' || c=='Q')
			{
				Game_Repeat=true ;
				break ;
			}
		}
		endwin();
		delete game ;
		if (Game_Repeat)
		{
			return 1 ;
		}
	}
	return 0;
}

////////////////////////swimming in the sea & flying in the sky //////////////////

#endif // PuzzleGame_H_

//1)

