#ifndef soap2sam_H_
#define soap2sam_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../include/gzstream/gzstream.h"

#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/comm.h"

using namespace std;
typedef long long  llong ;
int msort_main(int argc, char **argv) ;


class Para_Formt01 {
	public:
		string input_file ;
		string output_file ;
		int PE ;
		int sort ;
		string Dict ;
		Para_Formt01()
		{
			input_file="" ;
			output_file="" ;
			PE=0 ;
			sort=0;
		}
};

class SamLine
{
	public:
		string RID;
		int Flag ;
		string seq;
		string Qseq;
		string cigar;
		string chr;
		llong position ;
		int mapQ ;
		string NM_i ;
		string MD ;
		bool IF ;
		int isize ;
		llong coor ;
		string XorD ;
		void copy( SamLine *  B )
		{
			RID=B->RID;   Flag=B->Flag;    seq=B->seq ;
			Qseq=B->Qseq; cigar=B->cigar; chr=B->chr;
			position=B->position ; mapQ=B->mapQ;  IF=B->IF;
			NM_i=B->NM_i ;MD=B->MD ; isize=B->isize;
			coor=B->coor; XorD=B->XorD;
		}
		SamLine()
		{
			RID="";  seq=""; Qseq=""; cigar=""; chr ="";
			Flag=0 ; position=0; mapQ =0 ; IF=false;
			NM_i=""; MD="";
			isize=0; coor=0; XorD="*";
		}
		void rm ()
		{
			RID="";  seq=""; Qseq=""; cigar=""; chr ="";
			Flag=0 ; position=0; mapQ =0 ; IF=false;
			NM_i=""; MD="";
			isize=0; coor=0; XorD="*";
			//return 1 ;
		}
		void Print(ogzstream & OUT )
		{
			OUT<<RID<<"\t"<<Flag<<"\t"<<chr<<"\t"<<position<<"\t"<<mapQ<<"\t"<<cigar<<"\t"<<XorD<<"\t"<<coor<<"\t"<<isize<<"\t"<<seq<<"\t"<<Qseq<<"\t"<<NM_i<<"\t"<<MD<<endl;
		}
};

int  print_Ausage_Formt01()
{
	cout <<""
		"\n"
		"\tUsage: Soap2Sam  -InSoap <in.soap> -OutSam <out.sam> \n"
		"\n"
		"\t\t-InSoap  <str>   Input SortSoap file \n"
		"\t\t-OutSam  <str>   Output Sam file\n"
		"\n"
		"\t\t-Pair            if soap is PairOut,for flag\n" 
		"\t\t-Dict    <str>   Input Sam Head file\n"
		"\t\t-NoOri           if soap is no original\n"
		"\t\t                 same ReadID No Neighbors\n" 
		"\n"        
		"\t\t-help            show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_Formt01(int argc, char **argv , Para_Formt01 * para_Formt01  )
{
	if (argc <=2 ) {print_Ausage_Formt01();return 0;}

	for(int i = 1; i < argc; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InSoap" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Formt01->input_file=argv[i];
		}           
		else if (flag  ==  "OutSam")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Formt01->output_file=argv[i];
		}
		else if (flag  ==  "Dict")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Formt01->Dict=argv[i];
		}

		else if (flag  ==  "Pair" )
		{
			(para_Formt01->PE)=1;
		}
		else if (flag  ==  "NoOri" )
		{
			(para_Formt01->sort)=1;
		}       
		else if (flag  == "help")
		{
			print_Ausage_Formt01();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_Formt01->input_file).empty() || (para_Formt01->output_file).empty()  )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(para_Formt01->output_file)=add_Asuffix ( (para_Formt01->output_file) );
	return 1 ;
}


int matmis( string line ,string & Base ,int & data )
{    
	vector<string> inf;
	split(line,inf,"->");
	if (inf.size()<2)
	{
		return 0 ;
	}
	else
	{
		Base=inf[0];
		int L=inf[1].length();
		int i=0 ;
		for ( i=0; i<L ; i++ )
		{
			char N= (inf[1][i]) ;
			if ( N  == 'A' ||  N == 'C' ||  N == 'T'  ||  N == 'G' )
			{
				break ;
			}
		}
		string B=inf[1].substr(0,i);
		data=atoi(B.c_str());
		return 1 ;
	}
	//    if ($ARGV[0] =~ /^([ACGT])->(\d+)/i);
}

int mating ( SamLine * A ,  SamLine * B )
{
	int Insert=0;
	if (  (A->chr) != "*" && ( (A->chr) ==(B->chr))  )  //# then calculate $isize
	{
		llong  x1=( (A->Flag) & 0x10 ) ? (A->position)+((A->seq).length()) : (A->position);
		llong  x2=( (B->Flag) & 0x10 ) ? (B->position)+((B->seq).length()) : (B->position);
		Insert=x2-x1;
	}
	//# update mate coordinate
	if  ( (B->chr) != "*" )
	{
		A->coor=B->position;
		A->isize=Insert;
		A->XorD= ((B->chr) == (A->chr)) ? "=" : (B->chr) ; 
		if ((B->Flag) & 0x10 )
		{
			A->Flag |= 0x20 ;
		}
	}
	else
	{
		A->Flag |= 0x8;
	}

	if  ( (A->chr) != "*" )
	{
		B->coor=A->position;
		B->isize=0-Insert;
		B->XorD= ((A->chr) == (B->chr)) ? "=" : (A->chr) ; 
		if ((A->Flag) & 0x10 )
		{
			B->Flag |= 0x20 ;
		}
	}
	else
	{
		B->Flag |= 0x8;
	}    
	return 1;
}


int soap2sam ( string line , Para_Formt01 * para_Formt01 , SamLine *sam )
{
	vector<string> inf;
	split(line,inf," \t");
	int Length=inf.size();
	if ( Length < 9 || (inf[0].empty()) )
	{
		return 0 ;
	}
	sam->rm();
	int A=inf[3][0];
	if ( A>57 || A<48 ) // fix SOAP-2.1.x bugs
	{
		vector<string> tmp (Length-1);
		tmp[0]=inf[0]; tmp[1]=inf[1];   tmp[2]=inf[2]; 
		for(int ii=4 ; ii<Length ; ii++ )
		{
			tmp[ii-1]=tmp[ii];
		}
		inf.clear();
		inf=tmp ;
	}
	// readID //
	int RID_length=inf[0].length() ;
	//    sam->RID=getID(inf[0]);
	//*
	sam->RID=(inf[0]); 
	if ( RID_length >2 )
	{
		if ( inf[0][RID_length-2]== '/'  &&  ( (inf[0][RID_length-1]== '1')  || (inf[0][RID_length-1]== '2') ))
		{
			sam->RID=inf[0].substr(0, RID_length-2);                   
		}
	}
	///*///

	// initial flag (will be updated later)
	sam->Flag =0 ; 

	(sam->Flag) |= 1 | 1<<(inf[4] == "a" ? 6 : 7);
	if  (para_Formt01->PE)
	{
		(sam->Flag)  |= 2;
	}
	if (inf[6] == "-" )
	{           
		(sam->Flag) |= 0x10 ;
	}

	// # read & quality
	sam->seq=inf[1];
	int RLength=inf[1].length();
	int QLength=inf[2].length();
	sam->Qseq = (QLength> RLength ) ? inf[2].substr(0,RLength): inf[2] ;
	/*/////
	  QLength=(sam->Qseq).length();
	  for(string::size_type ix=0; ix<QLength; ix++)
	  {
	  (sam->Qseq)[ix]-=31 ; ////// chang the "#"  Quli to "B" Quli
	  }
	///*////
	// cigar 
	sam->cigar= Int2Str(RLength)+"M";

	// # coor
	sam->chr = inf[7]; sam->position = atoi(inf[8].c_str());

	// mapQ
	sam->mapQ  = (inf[3] == "1" ) ? 30 : 0;

	// # mate coordinate
	//$s->[6] = '*'; $s->[7] = $s->[8] = 0;

	// # aux 
	sam->NM_i="NM:i:"+inf[9];
	sam->MD="";
	A=atoi(inf[9].c_str());
	if (A)
	{
		string Base ;
		int data ;
		map <int ,string  > MAP ;
		for (int ii=10 ; ii<Length ; ii++ )
		{
			if (matmis( inf[ii], Base , data))
			{
				MAP.insert(map < int,string > :: value_type (data,Base));
			}
		}
		int a=0;
		map <int , string> :: iterator it=MAP.begin();
		for(it=MAP.begin() ; it!=MAP.end(); it++)
		{
			int c =(it->first) - a ;
			(sam->MD) += Int2Str(c) + (it->second);
			a += (c  + 1);
		}
		(sam->MD) += Int2Str(RLength-a);
	}
	else
	{
		(sam->MD)=Int2Str(RLength);
	}
	(sam->MD)="MD:Z:"+(sam->MD);
	sam->IF=true ;
	return  1;
}

int soap2sam_main(int argc, char *argv[])
{
	Para_Formt01 * para_Formt01 = new Para_Formt01;
	if (parse_Acmd_Formt01(argc, argv , para_Formt01 )==0)
	{
		delete  para_Formt01 ;
		return 0;
	}
	ogzstream OUT ((para_Formt01->output_file).c_str());
	if(!OUT.good())
	{
		cerr << "open InputFile error: "<<(para_Formt01->output_file)<<endl;
		return 1;
	}

	if (!(para_Formt01->Dict).empty())
	{
		Write_Sam_head (para_Formt01->Dict , OUT) ;
	} 

	if (para_Formt01->sort)
	{
		char * A = const_cast<char*>((para_Formt01->input_file).c_str());
		//string tmpo = (para_Formt01->output_file)+".tmp.gz";
		//char * B = const_cast<char*>(tmpo.c_str());
		//char * ssTmp[5]={"msort", "-k1", A , "-o" ,B};
		char * ssTmp[3]={"msort", "-k1", A };
		file_t *db;
		string  outPut ;
		db=ReadParaAnd ( 3 , ssTmp , outPut) ;
		sort_file_lines(db);   

		SamLine  *sam1 = new SamLine ;
		SamLine  *sam2 = new SamLine ;
		SamLine  *samtmp = new SamLine ;

		for(int i=0;i<db->line_size;i++)
		{
			string line=db->lines[i].str ;
			if ( soap2sam (line ,  para_Formt01 , sam1 ))
			{
				if ( (sam2->IF)  && ( (sam1->RID) == (sam2->RID))) 
				{
					mating( sam1 ,  sam2  );
					sam2->Print(OUT); sam2->rm();              
					sam1->Print(OUT); sam1->rm();
				}
				else
				{
					if ((sam2->IF))
					{
						sam2->Flag |= 0x8 ;
						sam2->Print(OUT);
						sam2->Flag |= 0x8 ;
					}
					samtmp->copy(sam2);
					sam2->copy(sam1); 
					sam1->copy(samtmp);
				}
			}
		}

		if ((sam2->IF))
		{
			sam2->Print(OUT); sam2->rm();
		}
		free_file_lines(db); 
		delete sam1 ;
		delete sam2 ;
		delete samtmp ;
		OUT.close();
		delete para_Formt01 ;
		return 1;
	}


	igzstream IN ((para_Formt01->input_file).c_str(),ifstream::in);

	if(!IN.good())
	{
		cerr << "open InputFile error: "<<(para_Formt01->input_file)<<endl;
		return 1;
	}

	SamLine  *sam1 = new SamLine ;
	SamLine  *sam2 = new SamLine ;
	SamLine  *samtmp = new SamLine ;

	while(!IN.eof())
	{
		string  line ;
		getline(IN,line);
		if ( soap2sam (line ,  para_Formt01 , sam1 ))
		{
			if ( (sam2->IF)  && ( (sam1->RID) == (sam2->RID) )) 
			{
				mating( sam1 ,  sam2  );
				sam2->Print(OUT); sam2->rm();              
				sam1->Print(OUT); sam1->rm();
			}
			else
			{
				if ((sam2->IF))
				{
					sam2->Flag |= 0x8 ;
					sam2->Print(OUT);
					sam2->Flag |= 0x8 ;
				}
				samtmp->copy(sam2);
				sam2->copy(sam1); 
				sam1->copy(samtmp);
			}
		}
	}

	if ((sam2->IF))
	{
		sam2->Print(OUT); sam2->rm();
	}

	delete sam1 ;
	delete sam2 ;
	delete samtmp ;

	OUT.close();
	IN.close();    
	delete para_Formt01 ;
	return 1;

}


///////// swimming in the sky and flying in the sea ////////////
//


#endif // soap2sam_H_

