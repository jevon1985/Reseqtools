#ifndef Soap_Split_H_
#define Soap_Split_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include "../ALL/comm.h"
#include "../ALL/kseq.h"
#include <ext/hash_map>
#include  "../include/gzstream/gzstream.h" 
using namespace std;
using namespace __gnu_cxx;

typedef long long llong ;


///////////////////
void  changid ( string & str  , llong & id )
{
	stringstream ss; 
	ss<<id; 
	string s=ss.str();
	str.replace(0,str.find("\t"),s);
	id++;
}

void  changid ( string & str1 , string & str2  , llong & id )
{
	stringstream ss; 
	ss<<id; 
	string s=ss.str();
	str1.replace(0,str1.find("\t"),s);
	str2.replace(0,str2.find("\t"),s);
	id++;
}

int cmpair2ID ( string ID1 , string ID2 )
{
	if  ( (ID2.length()<2) || (ID1.length()<2) ) {return 1 ;}
	string::size_type end_Aid1=ID1.size()-2 ;
	string::size_type end_Aid2=ID2.size()-2 ;
	string aa=ID1.substr(end_Aid1);
	string bb=ID2.substr(end_Aid2);
	if (aa == "/1"  || aa == "/2")  
	{
		ID1=ID1.substr(0,end_Aid1);
	}
	if (bb == "/2"  || aa == "/1" )
	{
		ID2=ID2.substr(0,end_Aid2);
	}
	if  (ID1 == ID2 )
	{
		return 0 ;
	}
	else
	{
		return 1 ;
	}
}

class Para_A2 {
	public:
		string InFile ;
		string InList  ;
		vector <string> Soap_AStat ;
		string OutDir ;
		string Inchr ;
		string OutStat;
		int gz ;
		int A ;
		Para_A2()
		{
			gz=1;
			A=0;
			InFile="";
			Inchr="";
			OutDir="";
			InList="";
		}

};




int  print_Ausage_A2()
{
	//cout<<argv[0]<<"  <chr.list><info.out><OutDir><SoapList>"<<endl;
	cout <<""
		"\n"
		"\tUsage: split -InFile <1.soap> -InFile <2.soap> -OutDir <ODir> -Ref <Ref.fa> -OutStat <info.out>\n"
		"\n"
		"\t\t-InFile     <str>   [Repeat] Input soap file for split\n"
		"\t\t-InList     <str>   Input soap file List for split\n"
		"\t\t-Ref        <str>   InPut Ref seq\n"        
		"\t\t-OutStat    <str>   Out file of stat the Insert size\n"
		"\n"
		"\t\t-OutDir     <str>   Output Dir for split file[./]\n"
		"\t\t-NoOutgz            OutPut file with No gz [NA]\n"
		"\n"
		"\t\t-help               show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_A2(int argc, char **argv,Para_A2 * para_A2 )
{
	if (argc <=2 ) {print_Ausage_A2(); return 0 ;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0 ;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFile" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_A2->InFile=argv[i];
			(para_A2->Soap_AStat).push_back(para_A2->InFile);
			(para_A2->A)=(para_A2->A)+4;
		}
		else if (flag  ==  "OutDir")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_A2->OutDir=argv[i];
		}
		else if (flag  ==  "OutStat")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_A2->OutStat=argv[i];
		}
		else if (flag  ==  "Ref")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_A2->Inchr=argv[i];
		}
		else if (flag  ==  "InList")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_A2->InList=argv[i];
			(para_A2->A)=(para_A2->A)+2;
		}
		else if (flag  == "NoOutgz")
		{
			para_A2->gz=0;
		}
		else if (flag  == "help")
		{
			print_Ausage_A2();return 0 ;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0 ;
		}
	}
	if  ((para_A2->Inchr).empty() || (para_A2->A)==0 || (para_A2->OutStat).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0 ;
	}
	return 1 ;
}


int ReadChrInfo (string InchrFile ,string OutFileDir , vector <string>  & FileV ,  map <string,int> &  Soap2Int )
{
	string chr_Ainfo=InchrFile+".chrlist";
	OutFileDir=OutFileDir+"/" ;
	if (access(chr_Ainfo.c_str(), 0) == 0)
	{

		igzstream IN (chr_Ainfo.c_str(),ifstream::in); // igzstream 
		if(!IN.good())
		{
			cerr << "open InputFile error: "<<InchrFile<<endl;
			return 1;
		}
		int aa= 0; 
		while(!IN.eof())
		{
			string  line ,chr ;
			getline(IN,line);
			if (line.length()<=0)  { continue  ; }
			if (line[0] == '#' )  { continue  ; }
			istringstream isone (line,istringstream::in);
			isone>>chr ;
			Soap2Int[chr]=aa;
			line=OutFileDir+chr ;
			FileV.push_back(line);
			aa++;
		}
		IN.close();

		int File_Acount=FileV.size();
		if (File_Acount>168)
		{
			cerr<<"Waining :chr num too much :"<<File_Acount<<endl ;
		}
		return  File_Acount ;
	}
	else
	{
		//*
		gzFile fp;
		kseq_t *seq;
		fp = gzopen(InchrFile.c_str(), "r");
		seq = kseq_init(fp);
		int l=0, File_Acount=0;
		ofstream RefList (chr_Ainfo.c_str());
		while ((l = kseq_read(seq)) >= 0)
		{        
			string chr=seq->name.s;
			if (RefList.good())
			{
				map <char,llong> Map;
				stat_str_base(seq->seq.s , Map ,seq->seq.l );
				llong N_Aleng= Map['N']+0+Map['n'] ;
				llong eff_Acout=(seq->seq.l)-N_Aleng ;
				llong GC_Aleng=Map['C']+Map['G'] +0 + Map['c']+Map['g'] ;
				llong samllleter= Map['c']+Map['g'] + Map['t']+Map['a']+0;
				RefList<<(seq->name.s)<<"\t"<<(seq->seq.l)<<"\t"<<N_Aleng<<"\t"<<eff_Acout<<"\t"<<GC_Aleng<<"\t"<<samllleter<<endl;
			}
			Soap2Int[chr]=File_Acount;
			string line=OutFileDir+chr ;
			FileV.push_back(line) ;
			File_Acount++;
		}

		kseq_destroy(seq);
		gzclose(fp);
		RefList.close();
		if (File_Acount>168)
		{
			cerr<<"Waining :chr num too much :"<<File_Acount<<endl ;
		}
		return  File_Acount ;
		///*////
	}
}







//int main( int argc,char *argv[] )
int Soap_Split_main( int argc,char *argv[] )
{
	Para_A2 * para_A2 = new Para_A2;
	(para_A2->OutDir)="./";
	if (parse_Acmd_A2( argc, argv,para_A2)==0)
	{
		delete para_A2 ;
		return 1;
	}
	vector <string> File ;
	map <string,int>  Soap2Int ;
	int File_Acount=ReadChrInfo (para_A2->Inchr,para_A2->OutDir, File , Soap2Int ) ;
	//    vector <string> Soap_AStat ;
	string  Lane ;

	if  (( (para_A2->A) & (0x2)) )
	{
		ReadList (para_A2->InList,para_A2->Soap_AStat ) ;
		Lane=para_A2->InList ;

	}
	if  ( (para_A2->A) > 2 )
	{
		//      Soap_AStat.push_back(para_A2->InFile);
		Lane=para_A2->InFile;
	}   


	// open file //
	ofstream Info ((para_A2->OutStat).c_str()) ;     
	string OutInsert=(para_A2->OutStat)+".insert";
	ofstream Insert (OutInsert.c_str());

	if(!Insert.good())
	{
		cerr << "open OutFile error: "<<OutInsert<<endl;
		return 1;
	}
	if(!Info.good())
	{
		cerr << "open OutStat error: "<<para_A2->OutStat<<endl;
		return 1;
	}

	if  ( (para_A2->gz)==0 )
	{

		ofstream *Soap2Chr = new ofstream[File_Acount] ;

		for (int i=0; i<File_Acount ; i++)
		{
			Soap2Chr[i].open(File[i].c_str()) ;
			if  (!Soap2Chr[i].good())
			{
				cerr<<"Can't open follow output:\n"<<File[i]<<endl;
			}
		}

		llong Read_Aid=1 ;
		llong total_Amap_Areads= 0 ;
		llong total_Asingle =0 ;
		llong total_Arepeat_Apair = 0;
		llong total_Auniq_Apair =0 ;
		llong total_Auniq_Alow_Apair=0 ;
		llong total_Auniq_Anormal_Apair =0 ;
		llong insert=0 ;
		int length1=0 ;
		map <llong, llong > map_Ainsert ;

		int Soap_AStat_Acount=(para_A2->Soap_AStat).size();
		Info<<"##chr\tUniqRead\tUniqDepth\tMeanReadLengUinq\tALLRead\tALLDepth\tMeanLengALL\tMeanReadLengALL\tMisMatchBaseALL\n";
		for (int i=0; i<Soap_AStat_Acount ; i++)
		{
			string SoapStat_ANow=(para_A2->Soap_AStat)[i]; 
			string ext =SoapStat_ANow.substr(SoapStat_ANow.rfind('/') ==string::npos ? SoapStat_ANow.length() : SoapStat_ANow.rfind('/') + 1);
			Info<<"##"<<ext<<endl ;
			llong   all_Aread=0 ;  llong uniq_Aread=0 ;
			llong  all_ADepth=0 ;  llong  uniq_ADepth=0;
			map <string , llong > Read_Achr ;
			map <string , llong > Depth_Achr ;
			map <string , llong >  Read_Auniq_Achr ;
			map <string , llong >  Depth_AUniq_Achr ;
			map <string , llong >  MisMatch;

			igzstream IN_ASoap (SoapStat_ANow.c_str(),ifstream::in); // igzstream
			string line1 ,line2 ;
			int back_Aline= 0;
			while(getline(IN_ASoap,line1))
			{   
				total_Amap_Areads+=2 ;
				string id1 ,temp ,chr1 , f1 ;
				int len1 ,hit1 ;
				long x1 ;
				if  (IN_ASoap.eof())
				{
					if (back_Aline==1)
					{
						if ( ((line2.length())<30) || ((line1.length())<30) ){break ;}
						line1=line2;
						back_Aline=0;
					}
					istringstream isone (line1,istringstream::in);
					isone>>id1 >> temp >> temp >> hit1 >> temp >> len1 >> f1 >>chr1 >> x1 ;         
					total_Amap_Areads--;
					changid(line1 , Read_Aid ) ;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;                
					all_ADepth+=len1 ; all_Aread++;                
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					stat_AMisMatch(line1,chr1,MisMatch) ;     
					if (hit1==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len1;
						Read_Auniq_Achr[chr1]++;
						Depth_AUniq_Achr[chr1]+=len1;
					}
					break ;
				}

				if (back_Aline==1)
				{
					string line3=line1 ;
					line1=line2;
					line2=line3 ;               
					back_Aline=0 ;
				}
				else
				{   
					line2=""; 
					getline(IN_ASoap,line2) ;
					if (line2.length()<10)
					{
						if (back_Aline==1)
						{
							if ( ((line2.length())<30) || ((line1.length())<30) ){break ;}
							line1=line2;
							back_Aline=0;                       
						}
						istringstream isone (line1,istringstream::in);
						isone>>id1 >> temp >> temp >> hit1 >> temp >> len1 >> f1 >>chr1 >> x1 ;         
						total_Amap_Areads--;
						changid(line1 , Read_Aid ) ;
						Soap2Chr[Soap2Int[chr1]]<<line1<<endl;                
						all_ADepth+=len1 ; all_Aread++;                
						Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
						stat_AMisMatch(line1,chr1,MisMatch) ;     
						if (hit1==1)
						{
							uniq_Aread++;
							uniq_ADepth+=len1;
							Read_Auniq_Achr[chr1]++;
							Depth_AUniq_Achr[chr1]+=len1;
						}
						break ;

					}

				}

				istringstream isone (line1,istringstream::in);
				isone>>id1 >> temp >> temp >> hit1 >> temp >> len1 >> f1 >>chr1 >> x1 ;                   
				//            streampos pos_AIN = IN_ASoap.tellg();
				string id2 ,chr2 , f2 ;
				int len2 ,hit2 ;
				long x2 ;
				istringstream isone2 (line2,istringstream::in);
				isone2>>id2 >> temp >> temp >> hit2 >> temp >> len2 >> f2 >>chr2 >> x2 ;
				if ( len1 > length1)
				{
					length1=len1 ;
				}
				if (cmpair2ID(id1,id2)==1) //single 
				{
					//IN_ASoap.seekg(pos_AIN,ios::beg);
					//IN_ASoap.seekg(pos_AIN,ios_Abase::beg);
					back_Aline=1;
					//               IN_ASoap.seekg(pos_AIN);
					total_Amap_Areads--;
					changid(line1 , Read_Aid  ) ;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;                
					all_ADepth+=len1 ; all_Aread++;                
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					stat_AMisMatch(line1,chr1,MisMatch) ;     
					if (hit1==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len1;
						Read_Auniq_Achr[chr1]++;
						Depth_AUniq_Achr[chr1]+=len1;
					}   
				}
				else if  ( chr1 != chr2 ) //single
				{
					changid(line1 ,line2 , Read_Aid  ) ;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;
					Soap2Chr[Soap2Int[chr2]]<<line2<<endl;
					all_ADepth+=(len1+len2); all_Aread+=2;
					stat_AMisMatch(line1,chr1,MisMatch) ;
					stat_AMisMatch(line2,chr2,MisMatch) ;
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					Read_Achr[chr2]++; Depth_Achr[chr2]+=len2 ;
					if (hit1==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len1;
						Read_Auniq_Achr[chr1]++;
						Depth_AUniq_Achr[chr1]+=len1;
					}
					if (hit2==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len2;
						Read_Auniq_Achr[chr2]++;
						Depth_AUniq_Achr[chr2]+=len2;
					}
				}
				else if ( hit1!=1  or  hit2!=1)
				{
					changid(line1 ,line2 , Read_Aid  ) ;
					total_Arepeat_Apair++;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;
					Soap2Chr[Soap2Int[chr2]]<<line2<<endl;
					all_ADepth+=(len1+len2); all_Aread+=2;
					stat_AMisMatch(line1,chr1,MisMatch) ;
					stat_AMisMatch(line2,chr2,MisMatch) ;
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					Read_Achr[chr2]++; Depth_Achr[chr2]+=len2 ;
					if (hit1==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len1;
						Read_Auniq_Achr[chr1]++;
						Depth_AUniq_Achr[chr1]+=len1;
					}
					if (hit2==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len2;
						Read_Auniq_Achr[chr2]++;
						Depth_AUniq_Achr[chr2]+=len2;
					}
				}
				else if  ( f1 == "+" && f2 == "-" )
				{
					changid(line1 ,line2 , Read_Aid  ) ; 
					insert = x2 - x1 + len2;
					map_Ainsert[insert]++;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;
					Soap2Chr[Soap2Int[chr2]]<<line2<<endl;
					all_ADepth+=(len1+len2); all_Aread+=2;
					stat_AMisMatch(line1,chr1,MisMatch) ;
					stat_AMisMatch(line2,chr2,MisMatch) ;
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					Read_Achr[chr2]++; Depth_Achr[chr2]+=len2 ;
					uniq_Aread++;
					uniq_ADepth+=len1;
					Read_Auniq_Achr[chr1]++;
					Depth_AUniq_Achr[chr1]+=len1;
					uniq_Aread++;
					uniq_ADepth+=len2;
					Read_Auniq_Achr[chr2]++;
					Depth_AUniq_Achr[chr2]+=len2;
				}
				else if  ( f1 == "-" && f2 == "+" )
				{
					changid(line1 ,line2 , Read_Aid  ) ; 
					insert = x1 - x2 + len1;
					map_Ainsert[insert]++;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;
					Soap2Chr[Soap2Int[chr2]]<<line2<<endl;
					all_ADepth+=(len1+len2); all_Aread+=2;
					stat_AMisMatch(line1,chr1,MisMatch) ;
					stat_AMisMatch(line2,chr2,MisMatch) ;
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					Read_Achr[chr2]++; Depth_Achr[chr2]+=len2 ;

					uniq_Aread++;
					uniq_ADepth+=len1;
					Read_Auniq_Achr[chr1]++;
					Depth_AUniq_Achr[chr1]+=len1;
					uniq_Aread++;
					uniq_ADepth+=len2;
					Read_Auniq_Achr[chr2]++;
					Depth_AUniq_Achr[chr2]+=len2;

				}
				else
				{
					changid(line1 ,line2 , Read_Aid  ) ;

					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;
					Soap2Chr[Soap2Int[chr2]]<<line2<<endl;
					all_ADepth+=(len1+len2); all_Aread+=2;
					stat_AMisMatch(line1,chr1,MisMatch) ;
					stat_AMisMatch(line2,chr2,MisMatch) ;
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					Read_Achr[chr2]++; Depth_Achr[chr2]+=len2 ;
					if (hit1==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len1;
						Read_Auniq_Achr[chr1]++;
						Depth_AUniq_Achr[chr1]+=len1;
					}
					if (hit2==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len2;
						Read_Auniq_Achr[chr2]++;
						Depth_AUniq_Achr[chr2]+=len2;
					}
				}
			}
			IN_ASoap.close();
			IN_ASoap.clear();

			if (back_Aline==1)
			{
				line1=line2;
				back_Aline=0;
				string id1 ,temp ,chr1 , f1 ;
				int len1 ,hit1 ;
				long x1 ;
				istringstream isone (line1,istringstream::in);
				isone>>id1 >> temp >> temp >> hit1 >> temp >> len1 >> f1 >>chr1 >> x1 ;         
				total_Amap_Areads++;
				changid(line1 , Read_Aid ) ;
				Soap2Chr[Soap2Int[chr1]]<<line1<<endl;                
				all_ADepth+=len1 ; all_Aread++;                
				Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
				stat_AMisMatch(line1,chr1,MisMatch) ;     
				if (hit1==1)
				{
					uniq_Aread++;
					uniq_ADepth+=len1;
					Read_Auniq_Achr[chr1]++;
					Depth_AUniq_Achr[chr1]+=len1;
				}
			}
			//////////swimming in the sky and flying in the sea ///////////

			llong missbase =0 ;

			map <string,int>  :: const_iterator map_Ait=Soap2Int.begin();
			double temp=0.0, temp2=0.0; 
			while(map_Ait!=Soap2Int.end())
			{
				string k_Achr=map_Ait->first  ;
				temp=0.0 ; temp2=0.0 ;
				if  (Read_Auniq_Achr.find(k_Achr)==Read_Auniq_Achr.end()) {  map_Ait++; continue ;}
				if  (Read_Auniq_Achr[k_Achr]!=0)
				{
					temp=(int((Depth_AUniq_Achr[k_Achr]*1.0/Read_Auniq_Achr[k_Achr])*100+0.5))/100.0;
				}
				if (Read_Achr[k_Achr]!=0)
				{
					temp2=(int((Depth_Achr[k_Achr]*1.0/Read_Achr[k_Achr])*100+0.5))/100.0;
				}
				missbase+=MisMatch[k_Achr];
				map_Ait++;
				Info<<k_Achr<<"\t"<<Read_Auniq_Achr[k_Achr]<<"\t"<<Depth_AUniq_Achr[k_Achr]<<"\t"<<temp<<"\t"<<Read_Achr[k_Achr]<<"\t"<<Depth_Achr[k_Achr]<<"\t"<<temp2<<"\t"<<MisMatch[k_Achr]<<endl ;
			}

			temp=0.0 ; temp2=0.0;
			if (uniq_Aread!=0)
			{
				temp=(int((uniq_ADepth*1.0/uniq_Aread)*100+0.5))/100.0 ;
			}
			if (all_Aread!=0)
			{
				//              temp2=(int((all_Aread*1.0/all_ADepth)*100+0.5))/100.0 ;
				temp2=(int((all_ADepth*1.0/all_Aread)*100+0.5))/100.0 ;
			}
			Info<<"#Genome\t"<<uniq_Aread<<"\t"<<uniq_ADepth<<"\t"<<temp<<"\t"<<all_Aread<<"\t"<<all_ADepth<<"\t"<<temp2<<"\t"<<missbase<<endl ;
			Read_Achr.clear();      Depth_Achr.clear();
			Read_Auniq_Achr.clear(); Depth_AUniq_Achr.clear();
			MisMatch.clear();
		}


		/////*/////
		Info.close();
		for (int i=0; i<File_Acount ; i++)
		{
			Soap2Chr[i].close() ;
		}
		llong  max_Ax = 0 ;
		llong max_Ay = 0;
		map <llong, llong >  :: const_iterator map_Ait=map_Ainsert.begin();

		while( map_Ait !=map_Ainsert.end())
		{
			if (max_Ay  <= (map_Ait->second) )
			{
				max_Ay= map_Ait->second ;
				max_Ax= map_Ait->first ;
			}
			map_Ait++;
		}

		llong cutoff = max_Ay /1000;
		if (cutoff<3) {cutoff=3 ;}

		map_Ait=map_Ainsert.begin();
		vector <llong> vectorInsert ;
		vector <llong> vectorCount ;
		vector <llong> vectorcumul ;

		while( map_Ait !=map_Ainsert.end())
		{
			if  (  (map_Ait->second) < cutoff )
			{
				total_Auniq_Alow_Apair +=  (map_Ait->second) ;
			}
			else
			{
				total_Auniq_Anormal_Apair +=  (map_Ait->second) ;
				vectorInsert.push_back(map_Ait->first);
				vectorCount.push_back( map_Ait->second ) ;
				vectorcumul.push_back(total_Auniq_Anormal_Apair);
			}
			map_Ait++;
		}

		////////////
		//
		llong median = llong( max_Ax+0 );

		llong Lsd=0;  llong Rsd=0 ; llong Lc=0 ; llong Rc=0 ;
		long LengVetor=long(vectorInsert.size())+0;
		for (long  i=0; i<LengVetor; i++) 
		{
			llong diff =llong (llong(vectorInsert[i]+0) - median) ;
			if (diff < 0) 
			{
				Lsd += vectorCount[i] * diff * diff ;
				Lc +=  vectorCount[i];
			}
			else if ( diff > 0) 
			{
				Rsd += vectorCount[i] * diff * diff;
				Rc += vectorCount[i];
			}
		}

		if (Lc!=0)
		{
			Lsd = llong( sqrt(Lsd/Lc));
		}
		if (Rc!=0)
		{
			Rsd = llong (sqrt(Rsd/Rc));
		}


		total_Auniq_Apair = total_Auniq_Alow_Apair + total_Auniq_Anormal_Apair;
		total_Asingle = total_Amap_Areads - total_Arepeat_Apair * 2 - total_Auniq_Apair * 2;

		Insert<< "#          Mapped reads: "<<total_Amap_Areads<<endl;
		Insert<< "#          Single reads: "<<total_Asingle<<endl;
		Insert<< "#           Repeat pair: "<<total_Arepeat_Apair<<endl;
		Insert<< "#             Uniq pair: "<<total_Auniq_Apair<<endl;
		Insert<< "#    low frequency pair: "<<total_Auniq_Alow_Apair<<endl;
		Insert<< "# normal frequency pair: "<<total_Auniq_Anormal_Apair<<endl;
		Insert<< "#        Peak: "<<median<<endl;
		Insert<< "#        SD: -"<<Lsd<<"/+"<<Rsd<<endl;

		llong lsd = llong (median) - 3*Lsd ;
		llong rsd = llong (median) + 3*Rsd ;

		string LaneT=Lane.substr(Lane.rfind('/') ==string::npos ?Lane.length() :Lane.rfind('/') + 1) ;
		if (!LaneT.empty()) {Lane=LaneT ;}
		string ext_Aaa =Lane.substr(Lane.rfind('.') ==string::npos ? Lane.length() : Lane.rfind('.') + 1);
		if (ext_Aaa.empty())
		{

		}
		else if (ext_Aaa == "soap" || ext_Aaa == "single")
		{
			Lane=Lane.substr(0,Lane.rfind('.'));
		}
		vector<string>  tokens ;
		split (Lane,tokens ,"_");
		if  (tokens.size()<6)
		{
			tokens.clear();        
			split (Lane,tokens ,".");
		}

		string  lib ="NA" ;
		if (tokens.size()>0)
		{
			lib = tokens[tokens.size()-1];
		}        
		if (lib.length()<3)
		{ 
			int tmpA=tokens.size()-3 ; 
			if (tmpA<0){tmpA=0 ;} 
			lib=tokens[tmpA] ;
		}
		else if (lib.length()<2) 
		{
			int tmpA=tokens.size()-2 ; 
			if (tmpA<0){tmpA=0 ;} 
			lib=tokens[tmpA] ;
		}
		else if (lib.length()<1) 
		{
			lib="NA";
		}
		cout<<Lane<<"\t"<<lib<<"\t1\t"<<length1<<"\t"<<length1<<"\t"<<median<<"\t"<<lsd<<"\t"<<rsd<<"\t"<<Lsd<<"\t"<<Rsd<<endl;

		for ( long i=0; i<LengVetor ; i++ )
		{
			Insert<<vectorInsert[i]<<"\t"<<vectorCount[i]<<endl;
		}
		Insert.close();
		delete [] Soap2Chr ;



	}
	else
	{







		ogzstream *Soap2Chr = new ogzstream[File_Acount] ;

		for (int i=0; i<File_Acount ; i++)
		{
			string AA=File[i]+".gz";
			Soap2Chr[i].open(AA.c_str()) ;
			if  (!Soap2Chr[i].good())
			{
				cerr<<"Can't open follow output:\n"<<AA<<endl;
			}
		}

		llong Read_Aid=1 ;
		llong total_Amap_Areads= 0 ;
		llong total_Asingle =0 ;
		llong total_Arepeat_Apair = 0;
		llong total_Auniq_Apair =0 ;
		llong total_Auniq_Alow_Apair=0 ;
		llong total_Auniq_Anormal_Apair =0 ;
		llong insert=0 ;
		int length1=0 ;
		map <llong, llong > map_Ainsert ;

		int Soap_AStat_Acount=(para_A2->Soap_AStat).size();
		Info<<"##chr\tUniqRead\tUniqDepth\tMeanReadLengUinq\tALLRead\tALLDepth\tMeanLengALL\tMeanReadLengALL\tMisMatchBaseALL\n";
		for (int i=0; i<Soap_AStat_Acount ; i++)
		{
			string SoapStat_ANow=(para_A2->Soap_AStat)[i]; 
			string ext =SoapStat_ANow.substr(SoapStat_ANow.rfind('/') ==string::npos ? SoapStat_ANow.length() : SoapStat_ANow.rfind('/') + 1);
			Info<<"##"<<ext<<endl ;
			llong   all_Aread=0 ;  llong uniq_Aread=0 ;
			llong  all_ADepth=0 ;  llong  uniq_ADepth=0;
			map <string , llong > Read_Achr ;
			map <string , llong > Depth_Achr ;
			map <string , llong >  Read_Auniq_Achr ;
			map <string , llong >  Depth_AUniq_Achr ;
			map <string , llong >  MisMatch;

			igzstream IN_ASoap (SoapStat_ANow.c_str(),ifstream::in); // igzstream
			string line1 ,line2 ;
			int back_Aline= 0;
			while(getline(IN_ASoap,line1))
			{   
				total_Amap_Areads+=2 ;
				string id1 ,temp ,chr1 , f1 ;
				int len1 ,hit1 ;
				long x1 ;

				if  (IN_ASoap.eof())
				{
					if (back_Aline==1)
					{
						if ( ((line2.length())<30) || ((line1.length())<30) ){break ;}
						line1=line2;
						back_Aline=0;                       
					}
					istringstream isone (line1,istringstream::in);
					isone>>id1 >> temp >> temp >> hit1 >> temp >> len1 >> f1 >>chr1 >> x1 ;         
					total_Amap_Areads--;
					changid(line1 , Read_Aid ) ;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;                
					all_ADepth+=len1 ; all_Aread++;                
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					stat_AMisMatch(line1,chr1,MisMatch) ;     
					if (hit1==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len1;
						Read_Auniq_Achr[chr1]++;
						Depth_AUniq_Achr[chr1]+=len1;
					}
					break ;
				}

				if (back_Aline==1)
				{
					string line3=line1 ;
					line1=line2;
					line2=line3 ;               
					back_Aline=0 ;
				}
				else
				{ 
					line2="";
					getline(IN_ASoap,line2) ;
					if (line2.length()<10)
					{
						if (back_Aline==1)
						{
							if ( ((line2.length())<30) || ((line1.length())<30) ){break ;}
							line1=line2;
							back_Aline=0;                       
						}
						istringstream isone (line1,istringstream::in);
						isone>>id1 >> temp >> temp >> hit1 >> temp >> len1 >> f1 >>chr1 >> x1 ;         
						total_Amap_Areads--;
						changid(line1 , Read_Aid ) ;
						Soap2Chr[Soap2Int[chr1]]<<line1<<endl;                
						all_ADepth+=len1 ; all_Aread++;                
						Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
						stat_AMisMatch(line1,chr1,MisMatch) ;     
						if (hit1==1)
						{
							uniq_Aread++;
							uniq_ADepth+=len1;
							Read_Auniq_Achr[chr1]++;
							Depth_AUniq_Achr[chr1]+=len1;
						}
						break ;

					}

				}

				istringstream isone (line1,istringstream::in);
				isone>>id1 >> temp >> temp >> hit1 >> temp >> len1 >> f1 >>chr1 >> x1 ;                   
				//            streampos pos_AIN = IN_ASoap.tellg();
				string id2 ,chr2 , f2 ;
				int len2 ,hit2 ;
				long x2 ;
				istringstream isone2 (line2,istringstream::in);
				isone2>>id2 >> temp >> temp >> hit2 >> temp >> len2 >> f2 >>chr2 >> x2 ;
				if ( len1 > length1)
				{
					length1=len1 ;
				}
				if (cmpair2ID(id1,id2)==1) //single 
				{
					back_Aline=1;
					total_Amap_Areads--;
					changid(line1 , Read_Aid  ) ;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;                
					all_ADepth+=len1 ; all_Aread++;                
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					stat_AMisMatch(line1,chr1,MisMatch) ;     
					if (hit1==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len1;
						Read_Auniq_Achr[chr1]++;
						Depth_AUniq_Achr[chr1]+=len1;
					}   
				}
				else if  ( chr1 != chr2 ) //single
				{
					changid(line1 ,line2 , Read_Aid  ) ;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;
					Soap2Chr[Soap2Int[chr2]]<<line2<<endl;
					all_ADepth+=(len1+len2); all_Aread+=2;
					stat_AMisMatch(line1,chr1,MisMatch) ;
					stat_AMisMatch(line2,chr2,MisMatch) ;
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					Read_Achr[chr2]++; Depth_Achr[chr2]+=len2 ;
					if (hit1==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len1;
						Read_Auniq_Achr[chr1]++;
						Depth_AUniq_Achr[chr1]+=len1;
					}
					if (hit2==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len2;
						Read_Auniq_Achr[chr2]++;
						Depth_AUniq_Achr[chr2]+=len2;
					}
				}
				else if ( hit1!=1  or  hit2!=1)
				{
					changid(line1 ,line2 , Read_Aid  ) ;
					total_Arepeat_Apair++;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;
					Soap2Chr[Soap2Int[chr2]]<<line2<<endl;
					all_ADepth+=(len1+len2); all_Aread+=2;
					stat_AMisMatch(line1,chr1,MisMatch) ;
					stat_AMisMatch(line2,chr2,MisMatch) ;
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					Read_Achr[chr2]++; Depth_Achr[chr2]+=len2 ;
					if (hit1==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len1;
						Read_Auniq_Achr[chr1]++;
						Depth_AUniq_Achr[chr1]+=len1;
					}
					if (hit2==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len2;
						Read_Auniq_Achr[chr2]++;
						Depth_AUniq_Achr[chr2]+=len2;
					}
				}
				else if  ( f1 == "+" && f2 == "-" )
				{
					changid(line1 ,line2 , Read_Aid  ) ; 
					insert = x2 - x1 + len2;
					map_Ainsert[insert]++;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;
					Soap2Chr[Soap2Int[chr2]]<<line2<<endl;
					all_ADepth+=(len1+len2); all_Aread+=2;
					stat_AMisMatch(line1,chr1,MisMatch) ;
					stat_AMisMatch(line2,chr2,MisMatch) ;
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					Read_Achr[chr2]++; Depth_Achr[chr2]+=len2 ;
					uniq_Aread++;
					uniq_ADepth+=len1;
					Read_Auniq_Achr[chr1]++;
					Depth_AUniq_Achr[chr1]+=len1;
					uniq_Aread++;
					uniq_ADepth+=len2;
					Read_Auniq_Achr[chr2]++;
					Depth_AUniq_Achr[chr2]+=len2;
				}
				else if  ( f1 == "-" && f2 == "+" )
				{
					changid(line1 ,line2 , Read_Aid  ) ; 
					insert = x1 - x2 + len1;
					map_Ainsert[insert]++;
					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;
					Soap2Chr[Soap2Int[chr2]]<<line2<<endl;
					all_ADepth+=(len1+len2); all_Aread+=2;
					stat_AMisMatch(line1,chr1,MisMatch) ;
					stat_AMisMatch(line2,chr2,MisMatch) ;
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					Read_Achr[chr2]++; Depth_Achr[chr2]+=len2 ;

					uniq_Aread++;
					uniq_ADepth+=len1;
					Read_Auniq_Achr[chr1]++;
					Depth_AUniq_Achr[chr1]+=len1;
					uniq_Aread++;
					uniq_ADepth+=len2;
					Read_Auniq_Achr[chr2]++;
					Depth_AUniq_Achr[chr2]+=len2;

				}
				else
				{
					changid(line1 ,line2 , Read_Aid  ) ;

					Soap2Chr[Soap2Int[chr1]]<<line1<<endl;
					Soap2Chr[Soap2Int[chr2]]<<line2<<endl;
					all_ADepth+=(len1+len2); all_Aread+=2;
					stat_AMisMatch(line1,chr1,MisMatch) ;
					stat_AMisMatch(line2,chr2,MisMatch) ;
					Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
					Read_Achr[chr2]++; Depth_Achr[chr2]+=len2 ;
					if (hit1==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len1;
						Read_Auniq_Achr[chr1]++;
						Depth_AUniq_Achr[chr1]+=len1;
					}
					if (hit2==1)
					{
						uniq_Aread++;
						uniq_ADepth+=len2;
						Read_Auniq_Achr[chr2]++;
						Depth_AUniq_Achr[chr2]+=len2;
					}
				}
			}
			IN_ASoap.close();
			IN_ASoap.clear();

			if (back_Aline==1)
			{
				line1=line2;
				back_Aline=0;
				string id1 ,temp ,chr1 , f1 ;
				int len1 ,hit1 ;
				long x1 ;
				istringstream isone (line1,istringstream::in);
				isone>>id1 >> temp >> temp >> hit1 >> temp >> len1 >> f1 >>chr1 >> x1 ;         
				total_Amap_Areads++;
				changid(line1 , Read_Aid ) ;
				Soap2Chr[Soap2Int[chr1]]<<line1<<endl;                
				all_ADepth+=len1 ; all_Aread++;                
				Read_Achr[chr1]++; Depth_Achr[chr1]+=len1 ;
				stat_AMisMatch(line1,chr1,MisMatch) ;     
				if (hit1==1)
				{
					uniq_Aread++;
					uniq_ADepth+=len1;
					Read_Auniq_Achr[chr1]++;
					Depth_AUniq_Achr[chr1]+=len1;
				}
			}
			//////////swimming in the sky and flying in the sea ///////////

			llong missbase =0 ;

			map <string,int>  :: const_iterator map_Ait=Soap2Int.begin();
			double temp=0.0, temp2=0.0; 
			while(map_Ait!=Soap2Int.end())
			{
				string k_Achr=map_Ait->first  ;
				temp=0.0 ; temp2=0.0 ;
				if  (Read_Auniq_Achr.find(k_Achr)==Read_Auniq_Achr.end()) {  map_Ait++; continue ;}
				if  (Read_Auniq_Achr[k_Achr]!=0)
				{
					temp=(int((Depth_AUniq_Achr[k_Achr]*1.0/Read_Auniq_Achr[k_Achr])*100+0.5))/100.0;
				}
				if (Read_Achr[k_Achr]!=0)
				{
					temp2=(int((Depth_Achr[k_Achr]*1.0/Read_Achr[k_Achr])*100+0.5))/100.0;
				}
				missbase+=MisMatch[k_Achr];
				map_Ait++;
				Info<<k_Achr<<"\t"<<Read_Auniq_Achr[k_Achr]<<"\t"<<Depth_AUniq_Achr[k_Achr]<<"\t"<<temp<<"\t"<<Read_Achr[k_Achr]<<"\t"<<Depth_Achr[k_Achr]<<"\t"<<temp2<<"\t"<<MisMatch[k_Achr]<<endl ;
			}

			temp=0.0 ; temp2=0.0;
			if (uniq_Aread!=0)
			{
				temp=(int((uniq_ADepth*1.0/uniq_Aread)*100+0.5))/100.0 ;
			}

			if (all_Aread!=0)
			{
				temp2=(int((all_ADepth*1.0/all_Aread)*100+0.5))/100.0 ;
			}

			Info<<"#Genome\t"<<uniq_Aread<<"\t"<<uniq_ADepth<<"\t"<<temp<<"\t"<<all_Aread<<"\t"<<all_ADepth<<"\t"<<temp2<<"\t"<<missbase<<endl ;

			Read_Achr.clear();      Depth_Achr.clear();
			Read_Auniq_Achr.clear(); Depth_AUniq_Achr.clear();
			MisMatch.clear();
		}


		/////*/////
		Info.close();
		for (int i=0; i<File_Acount ; i++)
		{
			Soap2Chr[i].close() ;
		}
		llong  max_Ax = 0 ;
		llong max_Ay = 0;
		map <llong, llong >  :: const_iterator map_Ait=map_Ainsert.begin();

		while( map_Ait !=map_Ainsert.end())
		{
			if (max_Ay  <= (map_Ait->second) )
			{
				max_Ay= map_Ait->second ;
				max_Ax= map_Ait->first ;
			}
			map_Ait++;
		}

		llong cutoff = max_Ay /1000;
		if (cutoff<3) {cutoff=3 ;}

		map_Ait=map_Ainsert.begin();
		vector <llong> vectorInsert ;
		vector <llong> vectorCount ;
		vector <llong> vectorcumul ;

		while( map_Ait !=map_Ainsert.end())
		{
			if  (  (map_Ait->second) < cutoff )
			{
				total_Auniq_Alow_Apair +=  (map_Ait->second) ;
			}
			else
			{
				total_Auniq_Anormal_Apair +=  (map_Ait->second) ;
				vectorInsert.push_back(map_Ait->first);
				vectorCount.push_back( map_Ait->second ) ;
				vectorcumul.push_back(total_Auniq_Anormal_Apair);
			}
			map_Ait++;
		}

		////////////
		//
		llong median = llong( max_Ax+0 );

		llong Lsd=0;  llong Rsd=0 ; llong Lc=0 ; llong Rc=0 ;
		long LengVetor=long(vectorInsert.size())+0;
		for (long  i=0; i<LengVetor; i++) 
		{
			llong diff =llong (llong(vectorInsert[i]+0) - median) ;
			if (diff < 0) 
			{
				Lsd += vectorCount[i] * diff * diff ;
				Lc +=  vectorCount[i];
			}
			else if ( diff > 0) 
			{
				Rsd += vectorCount[i] * diff * diff;
				Rc += vectorCount[i];
			}
		}

		if (Lc!=0)
		{
			Lsd = llong( sqrt(Lsd/Lc));
		}
		if (Rc!=0)
		{
			Rsd = llong (sqrt(Rsd/Rc));
		}


		total_Auniq_Apair = total_Auniq_Alow_Apair + total_Auniq_Anormal_Apair;
		total_Asingle = total_Amap_Areads - total_Arepeat_Apair * 2 - total_Auniq_Apair * 2;

		Insert<< "#          Mapped reads: "<<total_Amap_Areads<<endl;
		Insert<< "#          Single reads: "<<total_Asingle<<endl;
		Insert<< "#           Repeat pair: "<<total_Arepeat_Apair<<endl;
		Insert<< "#             Uniq pair: "<<total_Auniq_Apair<<endl;
		Insert<< "#    low frequency pair: "<<total_Auniq_Alow_Apair<<endl;
		Insert<< "# normal frequency pair: "<<total_Auniq_Anormal_Apair<<endl;
		Insert<< "#        Peak: "<<median<<endl;
		Insert<< "#        SD: -"<<Lsd<<"/+"<<Rsd<<endl;

		llong lsd = llong (median) - 3*Lsd ;
		llong rsd = llong (median) + 3*Rsd ;



		string LaneT=Lane.substr(Lane.rfind('/') ==string::npos ?Lane.length() :Lane.rfind('/') + 1) ;
		if (!LaneT.empty()) {Lane=LaneT ;}
		string ext_Aaa =Lane.substr(Lane.rfind('.') ==string::npos ? Lane.length() : Lane.rfind('.') + 1);

		if (ext_Aaa.empty())
		{

		}
		else if (ext_Aaa == "soap" || ext_Aaa == "single")
		{
			Lane=Lane.substr(0,Lane.rfind('.'));
		}
		vector<string>  tokens ;
		split (Lane,tokens ,"_");
		if  (tokens.size()<6)
		{
			tokens.clear();        
			split (Lane,tokens ,".");
		}

		string  lib ="NA" ;
		if (tokens.size()>0)
		{
			lib = tokens[tokens.size()-1];
		}        
		if (lib.length()<3)
		{ 
			int tmpA=tokens.size()-3 ; 
			if (tmpA<0){tmpA=0 ;} 
			lib=tokens[tmpA] ;
		}
		else if (lib.length()<2) 
		{
			int tmpA=tokens.size()-2 ; 
			if (tmpA<0){tmpA=0 ;} 
			lib=tokens[tmpA] ;
		}
		else if (lib.length()<1) 
		{
			lib="NA";
		}
		cout<<Lane<<"\t"<<lib<<"\t1\t"<<length1<<"\t"<<length1<<"\t"<<median<<"\t"<<lsd<<"\t"<<rsd<<"\t"<<Lsd<<"\t"<<Rsd<<endl;

		for (long i=0; i<LengVetor; i++)
		{
			Insert<<vectorInsert[i]<<"\t"<<vectorCount[i]<<endl;
		}
		Insert.close();

		delete [] Soap2Chr; 
	}
	delete para_A2 ;
	return 1 ;
}



/*/////////////////

///*/


////////////////////////swimming in the sea & flying in the sky //////////////////

#endif // Soap_Split_H_

///////// swimming in the sky and flying in the sea ////////////
