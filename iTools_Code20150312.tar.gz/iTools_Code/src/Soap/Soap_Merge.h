
#ifndef Soap_Merge_H_
#define Soap_Merge_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include "../include/gzstream/gzstream.h"
#include "./xam2soap/TSamCtrl.h"
#include "./xam2soap/Ttools.h"

using namespace std;

///////////////////

int  print_Ausage_A4()
{
	cout <<""
		"\n"
		"\tUsage: merge -InList <soap.list> -OutPut <out.soap> \n"
		"\n"
		"\t\t-InList     <str>   InPut SoapBychrSort[gz] file List for merge\n"
		"\t\t-OutPut     <str>   OutPut file of merge sort soap\n"
		"\n"
		"\t\t-OutNogz            OutPut file with NO gz\n"
		"\n"
		"\t\t-help               show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_A4(int argc, char **argv , In3str1v  * para_A4 )
{
	if (argc <=2 ) {print_Ausage_A4();return  0 ; }


	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_A4->InStr2=argv[i];
		}
		else if (flag  ==  "InList")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A4->InStr1=argv[i];
		}
		else if (flag  == "OutNogz")
		{
			para_A4->TF=false;
		}
		else if (flag  == "help")
		{
			print_Ausage_A4(); return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ( (para_A4->InStr1).empty() ||  (para_A4->InStr2).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}



void  run_Aread (igzstream & IN , long & position , ogzstream & OUT ,string & head_Aone, int Raw=9 )
	//void  run_Aread ( igzstream & IN , long & position , ofstream & OUT ,string & head_Aone )
{
	string line ,temp ;
	long posi_Anow ;
	OUT<<head_Aone<<endl ;

	for (int i =1 ; i>0 ; i++)
	{
		if (getline(IN,line))
		{
			istringstream isone (line,istringstream::in);
			for (int kk=1 ; kk<Raw ; kk++ )
			{
				isone>>temp ;
			}
			isone>>posi_Anow ;

			if (posi_Anow<=position)
			{
				OUT<<line<<endl ;
			}
			else
			{
				head_Aone=line; 
				position=posi_Anow ;
				break ;
			}
		}
		else
		{
			IN.close();
			position=-2;
			break ;
		}
	}    
}

void  run_Aread ( igzstream & IN , long & position , ofstream & OUT ,string & head_Aone , int Raw=9 )
{
	string line ,temp ;
	long posi_Anow ;
	OUT<<head_Aone<<endl ;

	for (int i =1 ; i>0 ; i++)
	{
		if (getline(IN,line))
		{
			istringstream isone (line,istringstream::in);
			//            isone>>temp>>temp>>temp>>temp>>temp>>temp>>temp>>temp>>posi_Anow ;
			for (int kk=1 ; kk<Raw ; kk++ )
			{
				isone>>temp ;
			}
			isone>>posi_Anow ;

			if (posi_Anow<=position)
			{
				OUT<<line<<endl ;
			}
			else
			{
				head_Aone=line; 
				position=posi_Anow ;
				break ;
			}
		}
		else
		{
			IN.close();
			position=-2;
			break ;
		}
	}    
}


void  run_Aread(TSamCtrl & IN , long & position , ogzstream & OUT ,string & head_one , int raw=9)
{
	string line ,temp ;
	long posi_now ;
	OUT<<head_one<<endl ;
	for (int i =1 ; i>0 ; i++)
	{
		if (IN.readline(line)!=-1)
		{
			istringstream isone (line,istringstream::in);
			for (int kk=1 ; kk<raw ; kk++ )
			{
				isone>>temp ;
			}
			isone>>posi_now ;
			if (posi_now<=position)
			{
				OUT<<line<<endl;
			}
			else
			{
				head_one=line;
				position=posi_now;
				break ;
			}
		}
		else
		{
			IN.close();
			position=-2;
			break ;
		}
	}
}



int chose_Afile ( const long Posi[] , const int count )
{
	long start=Posi[0] ;
	int min_Aflag=0;
	for ( int i=1 ; i <count  ; i++ )
	{
		if (  start <0 )
		{
			min_Aflag=i ;
			start=Posi[i];
		}
		else if ( Posi[i]>-1 &&  Posi[i]<start)
		{
			min_Aflag=i ;
			start=Posi[i];
		}
	}
	if  (Posi[min_Aflag]<0 )
	{
		min_Aflag=-2;
	}
	return  min_Aflag ;    
}


//////////////////

int Soap_Merge_main(int argc,char *argv[])
{
	In3str1v * para_A4 = new In3str1v;
	if (parse_Acmd_A4( argc, argv ,  para_A4 )==0)
	{
		delete para_A4 ;
		return 1;
	}

	vector <string> File ;

	int File_Acount=ReadList (  para_A4->InStr1  , File  );

	igzstream *Soap = new igzstream[File_Acount] ;
	long *Posi=new long[File_Acount] ;
	string temp ,line ;
	long min_Anow  ;
	string *Pring=new string[File_Acount] ;

	for (int i=0; i<File_Acount ; i++)
	{
		Soap[i].open(File[i].c_str(),ifstream::in) ;
		if  (Soap[i].good())
		{
			cout<<"soapfile\t"<<File[i]<<endl;
			getline(Soap[i],line) ;
			Pring[i]=line ;
			istringstream isone (line,istringstream::in);
			isone>>temp>>temp>>temp>>temp>>temp>>temp>>temp>>temp>>min_Anow;
			Posi[i]=min_Anow;
		}
		else
		{
			cerr<<File[i]<<"\tcan't open"<<endl ;
			Pring[i]=line ;
			Posi[i]=-2 ;
		}
	}
	//    ofstream OUT (OutFile.c_str());
	if ((para_A4->TF))
	{
		para_A4->InStr2=add_Asuffix(para_A4->InStr2);
		ogzstream OUT ((para_A4->InStr2).c_str());
		if(!OUT.good())
		{
			cerr << "open OutFile error: "<<para_A4->InStr2<<endl;
			return 1;
		}
		int file_Arun_Acout=chose_Afile(Posi , File_Acount) ;
		while( file_Arun_Acout > -1 )
		{        
			run_Aread(Soap[file_Arun_Acout],Posi[file_Arun_Acout],OUT,Pring[file_Arun_Acout]);
			file_Arun_Acout=chose_Afile ( Posi, File_Acount ) ;
		}
		OUT.close();
	}
	else
	{
		ofstream OUT ((para_A4->InStr2).c_str());
		if(!OUT.good())
		{
			cerr << "open OutFile error: "<<para_A4->InStr2<<endl;
			return 1;
		}
		int file_Arun_Acout=chose_Afile(Posi , File_Acount) ;
		while( file_Arun_Acout > -1 )
		{        
			run_Aread(Soap[file_Arun_Acout],Posi[file_Arun_Acout],OUT,Pring[file_Arun_Acout]);
			file_Arun_Acout=chose_Afile ( Posi, File_Acount ) ;
		}
		OUT.close();

	}
	delete para_A4 ;
	delete [] Pring ;
	delete [] Soap ;
	delete [] Posi ;
	return 0 ;
}

#endif // Soap_Merge_H_

////////////////////////swimming in the sea & flying in the sky //////////////////

///////// swimming in the sky and flying in the sea ////////////
