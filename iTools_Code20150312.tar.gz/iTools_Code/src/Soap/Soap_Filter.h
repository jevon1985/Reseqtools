#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
using namespace std;
typedef long long llong ;


class Para_A6 {
	public:
		string InPut_Afile ;
		string OutPut_Afile ;
		llong start ;
		llong end ;
		string chr;
		int minLeng ;
		int maxHit ;
		Para_A6()
		{
			start=0;
			end=10000000000;
			minLeng=30 ;
			maxHit =1 ;
			chr="";
		}
};




int  print_Ausage_A6()
{
	cout <<""
		"\n"
		"\tUsage: filter  -InPut <in.soap> \n"
		"\n"
		"\t\t-InPut     <str>   InPut Soap File\n"
		"\n"
		"\t\t-OutPut    <str>   OutPut file/file.gz,or [STDOUT]\n"
		"\t\t-MaxHit    <int>   the max hit of read[1]\n" 
		"\t\t-MinLeng   <int>   the min length of read[30]\n" 
		"\t\t-Start     <int>   the start position out[0]\n" 
		"\t\t-End       <int>   the end position out[1e10]\n" 
		"\t\t-Chr       <str>   only the [chr] out[all]\n" 
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_A6(int argc, char **argv, Para_A6 * para_A6)
{
	if (argc <=2 ) {print_Ausage_A6();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_A6->InPut_Afile=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0; }
			i++;
			para_A6->OutPut_Afile=argv[i];
		}
		else if (flag  ==  "Chr")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0; }
			i++;
			para_A6->chr=argv[i];
		}
		else if (flag  ==  "MaxHit")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_A6->maxHit=atoi(argv[i]);
		}
		else if (flag  ==  "MinLeng")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_A6->minLeng=atoi(argv[i]);
		}
		else if (flag  ==  "End")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A6->end=atol(argv[i]);
		}
		else if (flag  ==  "Start")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0; }
			i++;
			para_A6->start=atol(argv[i]);
		}
		else if (flag  == "help")
		{
			print_Ausage_A6();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_A6->InPut_Afile).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}


int filter ( Para_A6 * para_A6,string line)
{
	vector<string> inf;
	split(line,inf," \t" );
	int A=atoi(inf[3].c_str()) ;
	if (A>(para_A6->maxHit)) { return 0 ; }
	A=atoi(inf[5].c_str()) ;
	if (A<(para_A6->minLeng)) { return 0 ; }
	llong BB = atoi(inf[8].c_str()) ;
	if (BB<(para_A6->start)) { return 0 ; }
	if (BB>(para_A6->end)) { return 0 ; }
	cout<<line<<endl;
	return 1 ;
}

int filter ( Para_A6 * para_A6,string line, string chr )
{
	vector<string> inf;
	split(line,inf," \t" );
	int A=atoi(inf[3].c_str()) ;
	if (inf[7]!=chr) { return 0 ; }
	if (A>(para_A6->maxHit)) { return 0 ; }
	A=atoi(inf[5].c_str()) ;
	if (A<(para_A6->minLeng)) { return 0 ; }
	llong BB = atoi(inf[8].c_str()) ;
	if (BB<(para_A6->start)) { return 0 ; }
	if (BB>(para_A6->end)) { return 0 ; }
	cout<<line<<endl;
	return 1 ;
}

int filter ( Para_A6 * para_A6, string line , ogzstream & OUT )
{
	vector<string> inf;
	split(line,inf," \t" );
	int A=atoi(inf[3].c_str()) ;
	if (A>(para_A6->maxHit)) { return 0 ; }
	A=atoi(inf[5].c_str()) ;
	if (A<(para_A6->minLeng)) { return 0 ; }
	llong BB = atoi(inf[8].c_str()) ;
	if (BB<(para_A6->start)) { return 0 ; }
	if (BB>(para_A6->end)) { return 0 ; }
	OUT<<line<<endl;
	return 1 ;
}

int filter ( Para_A6 * para_A6,string line, string chr , ogzstream & OUT )
{
	vector<string> inf;
	split(line,inf," \t" );
	int A=atoi(inf[3].c_str()) ;
	if (inf[7]!=chr) { return 0 ; }
	if (A>(para_A6->maxHit)) { return 0 ; }
	A=atoi(inf[5].c_str()) ;
	if (A<(para_A6->minLeng)) { return 0 ; }
	llong BB = atoi(inf[8].c_str()) ;
	if (BB<(para_A6->start)) { return 0 ; }
	if (BB>(para_A6->end)) { return 0 ; }
	OUT<<line<<endl;
	return 1 ;
}






//programme entry
///////// swimming in the sky and flying in the sea ////////////
int Soap_Filter_main(int argc, char **argv)
{
	Para_A6 * para_A6 = new Para_A6;
	if (parse_Acmd_A6(argc, argv , para_A6 )==0)
	{
		delete para_A6 ; 
		return 0 ;
	}
	igzstream IN (para_A6->InPut_Afile.c_str(),ifstream::in); // ifstream  + gz 

	if(!IN.good())
	{
		cerr << "open IN File error: "<<para_A6->InPut_Afile<<endl;
		return 1;
	}

	if ( ((para_A6->chr).empty()) && ((para_A6->OutPut_Afile).empty()) )
	{
		while(!IN.eof())
		{
			string  line ;
			getline(IN,line);
			if (line.length()<=0)  { continue ; }
			filter ( para_A6, line) ;
		}
	}
	else if ( ((para_A6->chr).empty()) && (!(para_A6->OutPut_Afile).empty()) )
	{
		para_A6->OutPut_Afile=add_Asuffix(para_A6->OutPut_Afile);                
		ogzstream  OUT (para_A6->OutPut_Afile.c_str());
		if(!OUT.good())
		{
			cerr << "open OUT File error: "<<para_A6->OutPut_Afile<<endl;
			return 1;
		} 
		while(!IN.eof())
		{
			string  line ;
			getline(IN,line);
			if (line.length()<=0)  { continue ; }
			filter (para_A6,line ,OUT) ;
		}
		OUT.close();
	}
	else if ( (!(para_A6->chr).empty()) && ((para_A6->OutPut_Afile).empty()) )
	{
		while(!IN.eof())
		{
			string  line ;
			getline(IN,line);
			if (line.length()<=0)  { continue ; }
			filter (para_A6,line,para_A6->chr) ;
		}
	}
	else if ( (!(para_A6->chr).empty()) && (!(para_A6->OutPut_Afile).empty()) )
	{
		para_A6->OutPut_Afile=add_Asuffix(para_A6->OutPut_Afile);                
		ogzstream  OUT (para_A6->OutPut_Afile.c_str());
		if(!OUT.good())
		{
			cerr << "open OUT File error: "<<para_A6->OutPut_Afile<<endl;
			return 1;
		} 
		while(!IN.eof())
		{
			string  line ;
			getline(IN,line);
			if (line.length()<=0)  { continue ; }
			filter (para_A6, line ,para_A6->chr ,OUT) ;
		}
		OUT.close();
	}
	delete para_A6 ;
	IN.close();
	return 0;
}

///////// swimming in the sky and flying in the sea ////////////
