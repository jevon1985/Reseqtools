#ifndef Xam_Stat_H_
#define Xam_Stat_H_


#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../include/zlib/zlib.h"
#include <iomanip>
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../Soap/Soap_Stat.h"
#include "../ALL/comm.h"
#include "../include/gzstream/gzstream.h"
#include "../Soap/xam2soap/Ttools.h"
#include "../Soap/xam2soap/TSamCtrl.h"
#include "../Soap/xam2soap/Ttools.h"

using namespace std;

typedef char Base;
typedef unsigned long long ubit64_t;


class Para_Xam05 {
	public:
		string InFile ;
		string Ref ;
		string OutStat;
		string InList ;
		int SiteD ;
		bool ISSam ;
		Para_Xam05()
		{
			InFile="";
			Ref="";
			SiteD=0;
			OutStat="";
			ISSam=true;
		}

};


int  print_Ausage_Xam05()
{
	cout <<""
		"\n"
		"\tUsage: stat -InFile <1.sam> -OutStat <info.out> -Ref <Ref.fa>\n"
		"\n"
		"\t\t-InFile    <str>   Input Sort Sam,Bam file for Stat\n"
		"\t\t-InList    <str>   Input Sort Sam,Bam ByChr file List for Stat\n"
		"\t\t-Ref       <str>   Input Ref seq\n"  
		"\t\t-OutStat   <str>   Out file of stat\n"
		"\n"
		"\t\t-Bam               If InPut File is Bam\n"
		"\t\t-SiteD     <int>   Out every sites Depth[0]\n"
		"\t\t                   [0,1,2,3]0:NA;1:all_depth;2:uniq_depth\n"
		"\t\t                   3:Four BaseDepth \n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_Xam05(int argc, char **argv, Para_Xam05 * para_Xam05 )
{
	if (argc <=2 ) {print_Ausage_Xam05();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFile" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam05->InFile=argv[i];
		}
		else if (flag  == "InList" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_Xam05->InList=argv[i];
		}
		else if (flag  ==  "OutStat")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam05->OutStat=argv[i];
		}
		else if (flag  ==  "SiteD")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam05->SiteD=atoi(argv[i]);
		}
		else if (flag  ==  "Ref")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_Xam05->Ref=argv[i];
		}
		else if (flag  == "Bam")
		{
			para_Xam05->ISSam=false ;
		}
		else if (flag  == "help")
		{
			print_Ausage_Xam05();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if ( (para_Xam05->InFile).empty() &&  (para_Xam05->InList).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	else if((para_Xam05->Ref).empty() || (para_Xam05->OutStat).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}


///sam ///

int  StatSam_Arg_2 ( map<int,DepthDis> & DepDis  , ubit64_t Chr_Length , ubit64_t Eff_length , string  & chr , igzstream &  IN , ofstream & OUT  , string  & linesoap  , ogzstream  & Depth )
{

	ubit64_t Uniq_Read=0  ;
	ubit64_t All_Read=0  ;
	ubit64_t Uniq_Base=0  ;
	ubit64_t All_Base =0 ;
	//    ubit64_t Uniq_MisMatch =0 ;
	//    ubit64_t All_MisMatch =0 ;
	ubit64_t Uniq_coverage=0 ;
	ubit64_t All_coverage=0 ;

	int WindosL=5000000, maxReadLength=20000;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;
	//  int windos_Amax=bin-1*maxReadLength;

	//ubit64_t  Start=0 , End=Start+bin-3*ReadMax , End_Aadd=Start+bin-2*ReadMax ;

	//    map <string , llong >  MisMatchMap ; 
	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	int *depth= new int[bin];
	int *Uniqdepth= new int[bin];
	memset (depth , 0 , sizeof(int)*bin);
	memset (Uniqdepth, 0 , sizeof(int)*bin);
	//   for (int ii=0; ii< bin ; ii++ ) {depth[ii]=0 ;}
	string  Nowchr ;
	Depth<<">"<<chr<<endl;
	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++ )
	{   
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID , Flag  ;
		int hit , Read_leng ;
		istringstream isoneA (linesoap,istringstream::in);
		//isoneA>>ID >> seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;
		isoneA>>ID>>Flag>>Nowchr>>position ;
		while( (!IN.eof()) && position<=End_Ai  &&  Nowchr==chr ) 
		{
			vector<string> inf;
			split(linesoap,inf," \t");
			Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
			position=atol(inf[3].c_str());
			Read_leng=inf[9].size();
			if(Read_leng>maxReadLength)
			{
				getline(IN, linesoap );
				istringstream isoneA (linesoap,istringstream::in);
				isoneA>>ID>>Flag>>Nowchr>>position ;
				continue ;
			}
			int vec_size=inf.size();
			hit = 1;
			for (int i = 11; i < vec_size ; i++) {
				if (inf[i].find(HIT_COUNT_XA) != std::string::npos)
				{
					vector <string> tmp ;
					split( inf[i] ,  tmp , ";");
					hit=1+tmp.size();
					break;
				}
				else if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTU)!= std::string::npos)
				{
					hit =1;
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTR)!= std::string::npos)
				{
					hit =2;
					break;
				}
			}




			//            istringstream isone (linesoap,istringstream::in);
			//            isone >>ID>>seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;

			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}

			All_Read++  ;
			All_Base+=Read_leng ;
			//        int MisMatchDD=stat_AMisMatch (linesoap, Nowchr , MisMatchMap);
			//          All_MisMatch+=MisMatchDD ;

			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				if (inf[9][jj]=='N'){continue ;}
				int key_depth= Stat_vetor  + jj  ;
				depth[key_depth]++;
			}

			if (hit==1)
			{
				Uniq_Read++;
				Uniq_Base+=Read_leng ;
				//              Uniq_MisMatch+=MisMatchDD ;
				for(int jj=0 ; jj<Read_leng ; jj++)
				{
					if (inf[9][jj]=='N'){continue ;}
					int key_depth= position - Start_Ai + jj -1 ;
					Uniqdepth[key_depth]++;
				}
			}
			getline(IN, linesoap ) ;
			istringstream isoneA (linesoap,istringstream::in);
			isoneA>>ID>>Flag>>Nowchr>>position ;
		}

		if (End_Ai> (Chr_Length))
		{
			End_Ai=Chr_Length;
		}

		//for (int  ie = 0   ; ie < windos_Alen ; ie++ )
		for ( ubit64_t iee = Start_Ai   ; iee < End_Ai ; iee++ )
		{
			int ie = iee-Start_Ai ;
			if (depth[ie]!=0) {All_coverage++;}
			if (Uniqdepth[ie]!=0) { Uniq_coverage++; }
			map <int,DepthDis> :: iterator it=DepDis.find(depth[ie]);
			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DA=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(depth[ie],tmp));
			}
			else
			{
				(it->second).DA++;
			}

			it=DepDis.find(Uniqdepth[ie]);

			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DB=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(Uniqdepth[ie],tmp));
			}
			else
			{
				(it->second).DB++;
			}

			Depth<<Uniqdepth[ie]<<" ";
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}
		Depth<<endl;
		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			depth[tmpj]=depth[ie];
			Uniqdepth[tmpj]=Uniqdepth[ie];
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}
		if  (Nowchr!=chr)
		{
			break;
		}
	} 
	/// print out ///

	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<chr<<"\t"<<Uniq_Base*1.0/Eff_length<<"\t"<<Uniq_coverage*100.0/Eff_length<<"\t"<<Uniq_Base<<"\t"<<Uniq_coverage<<"\t"<<Uniq_Read<<"\t";
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<All_Base*1.0/Eff_length<<"\t"<<All_coverage*100.0/Eff_length<<"\t"<<All_Base<<"\t"<<All_coverage<<"\t"<<All_Read<<"\t"<<Eff_length<<"\t"<<Chr_Length<<endl ;

	chr=Nowchr ;

	delete [] depth ;
	delete [] Uniqdepth ;

	if ((!IN.eof())) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}




int  StatSam_Arg_1 (  map<int,DepthDis> & DepDis ,ubit64_t Chr_Length , ubit64_t Eff_length , string & chr , igzstream &  IN , ofstream & OUT  , string  & linesoap  , ogzstream  & Depth  )
{

	ubit64_t Uniq_Read=0  ;
	ubit64_t All_Read=0  ;
	ubit64_t Uniq_Base=0  ;
	ubit64_t All_Base =0 ;
	//    ubit64_t Uniq_MisMatch =0 ;
	//    ubit64_t All_MisMatch =0 ;
	ubit64_t Uniq_coverage=0 ;
	ubit64_t All_coverage=0 ;

	int WindosL=5000000, maxReadLength=20000;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;
	//  int windos_Amax=bin-1*maxReadLength;

	//ubit64_t  Start=0 , End=Start+bin-3*ReadMax , End_Aadd=Start+bin-2*ReadMax ;

	//  map <string , llong >  MisMatchMap ; 
	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	int *depth= new int[bin];
	int *Uniqdepth= new int[bin];
	memset (depth , 0 , sizeof(int)*bin);
	memset (Uniqdepth, 0 , sizeof(int)*bin);

	//  for (int ii=0; ii< bin ; ii++ ) {depth[ii]=0 ;}
	string  Nowchr ;
	Depth<<">"<<chr<<endl;
	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++)
	{   
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID ,Flag ;
		int hit , Read_leng ;
		istringstream isoneA (linesoap,istringstream::in);
		//isoneA>>ID >> seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;
		isoneA>>ID>>Flag>>Nowchr>>position ;
		while( (!IN.eof()) && position<=End_Ai  &&  Nowchr==chr ) 
		{
			vector<string> inf;
			split(linesoap,inf," \t");
			Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
			position=atol(inf[3].c_str());
			Read_leng=inf[9].size();
			if(Read_leng>maxReadLength)
			{
				getline(IN, linesoap );
				istringstream isoneA (linesoap,istringstream::in);
				isoneA>>ID>>Flag>>Nowchr>>position ;
				continue ;
			}
			int vec_size=inf.size();
			hit = 1;

			for (int i = 11; i < vec_size ; i++) {
				if (inf[i].find(HIT_COUNT_XA) != std::string::npos)
				{
					vector <string> tmp ;
					split( inf[i] ,  tmp , ";");
					hit=1+tmp.size();
					break;
				}
				else if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTU)!= std::string::npos)
				{
					hit =1;
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTR)!= std::string::npos)
				{
					hit =2;
					break;
				}
			}
			//          istringstream isone (linesoap,istringstream::in);
			//          isone >>ID>>seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;

			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}

			All_Read++ ;
			All_Base+=Read_leng ;
			//          int MisMatchDD=stat_AMisMatch (linesoap, Nowchr , MisMatchMap);
			//          All_MisMatch+=MisMatchDD ;


			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				if (inf[9][jj]=='N'){continue ;}
				int key_depth= Stat_vetor  + jj  ;
				depth[key_depth]++;
			}

			if (hit==1)
			{
				Uniq_Read++;
				Uniq_Base+=Read_leng ;
				//              Uniq_MisMatch+=MisMatchDD ;
				for(int jj=0 ; jj<Read_leng ; jj++)
				{
					if (inf[9][jj]=='N'){continue ;}
					int key_depth= position - Start_Ai + jj -1 ;
					Uniqdepth[key_depth]++;
				}
			}
			getline(IN, linesoap ) ;
			istringstream isoneA (linesoap,istringstream::in);
			isoneA>>ID>>Flag>>Nowchr>>position ;
		}

		if (End_Ai> (Chr_Length))
		{
			End_Ai=Chr_Length;
		}

		for ( ubit64_t iee = Start_Ai   ; iee < End_Ai ; iee++ )
		{
			int ie = iee-Start_Ai ;
			if (depth[ie]!=0) {All_coverage++;}
			if (Uniqdepth[ie]!=0) { Uniq_coverage++; }
			Depth<<depth[ie]<<" ";
			map <int,DepthDis> :: iterator it=DepDis.find(depth[ie]);
			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DA=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(depth[ie],tmp));
			}
			else
			{
				(it->second).DA++;
			}

			it=DepDis.find(Uniqdepth[ie]);

			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DB=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(Uniqdepth[ie],tmp));
			}
			else
			{
				(it->second).DB++;
			}

			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}
		Depth<<endl;
		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			depth[tmpj]=depth[ie];
			Uniqdepth[tmpj]=Uniqdepth[ie];
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}
		if  (Nowchr!=chr)
		{
			break;
		}

	} 

	/// print out ///
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<chr<<"\t"<<Uniq_Base*1.0/Eff_length<<"\t"<<Uniq_coverage*100.0/Eff_length<<"\t"<<Uniq_Base<<"\t"<<Uniq_coverage<<"\t"<<Uniq_Read<<"\t";
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<All_Base*1.0/Eff_length<<"\t"<<All_coverage*100.0/Eff_length<<"\t"<<All_Base<<"\t"<<All_coverage<<"\t"<<All_Read<<"\t"<<Eff_length<<"\t"<<Chr_Length<<endl ;


	delete [] depth ;
	delete [] Uniqdepth ;
	chr=Nowchr ;
	if ((!IN.eof())) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}




int  StatSam_Arg_3 (  map<int,DepthDis> & DepDis ,ubit64_t Chr_Length , ubit64_t Eff_length , string & chr , igzstream &  IN , ofstream & OUT  , string  & linesoap  , ogzstream  & Depth  )
{

	ubit64_t Uniq_Read=0  ;
	ubit64_t All_Read=0  ;
	ubit64_t Uniq_Base=0  ;
	ubit64_t All_Base =0 ;

	ubit64_t Uniq_coverage=0 ;
	ubit64_t All_coverage=0 ;

	int WindosL=5000000, maxReadLength=20000;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;


	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	int *depth= new int[bin];

	int *depthA= new int[bin];
	int *depthC= new int[bin];
	int *depthT= new int[bin];
	int *depthG= new int[bin];
	int *Uniqdepth= new int[bin];
	memset (depth , 0 , sizeof(int)*bin);
	memset (depthA , 0 , sizeof(int)*bin);
	memset (depthC , 0 , sizeof(int)*bin);
	memset (depthT , 0 , sizeof(int)*bin);
	memset (depthG , 0 , sizeof(int)*bin);

	memset (Uniqdepth, 0 , sizeof(int)*bin);

	string  Nowchr ;
	Depth<<">"<<chr<<"  #Format:position A_Depth C_Depth T_Depth G_Depth"<<endl;
	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++)
	{   
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID ,Flag ;
		int hit , Read_leng ;
		istringstream isoneA (linesoap,istringstream::in);
		isoneA>>ID>>Flag>>Nowchr>>position ;
		while( (!IN.eof()) && position<=End_Ai  &&  Nowchr==chr ) 
		{
			vector<string> inf;
			split(linesoap,inf," \t");
			Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
			position=atol(inf[3].c_str());
			Read_leng=inf[9].size();
			if(Read_leng>maxReadLength)
			{
				getline(IN, linesoap );
				istringstream isoneA (linesoap,istringstream::in);
				isoneA>>ID>>Flag>>Nowchr>>position ;
				continue ;
			}
			int vec_size=inf.size();
			hit = 1;

			for (int i = 11; i < vec_size ; i++) {
				if (inf[i].find(HIT_COUNT_XA) != std::string::npos)
				{
					vector <string> tmp ;
					split( inf[i] ,  tmp , ";");
					hit=1+tmp.size();
					break;
				}
				else if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTU)!= std::string::npos)
				{
					hit =1;
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTR)!= std::string::npos)
				{
					hit =2;
					break;
				}
			}


			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}

			All_Read++ ;
			All_Base+=Read_leng ;

			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				if (inf[9][jj]=='N'){continue ;}
				int key_depth= Stat_vetor  + jj;
				depth[key_depth]++;
				if (inf[9][jj] == 'A')
				{
					depthA[key_depth]++;
				}
				else if (inf[9][jj] == 'C')
				{
					depthC[key_depth]++;
				}
				else if (inf[9][jj] == 'T')
				{
					depthT[key_depth]++;
				}
				else if(inf[9][jj] == 'G')
				{
					depthG[key_depth]++;
				}
			}

			if (hit==1)
			{
				Uniq_Read++;
				Uniq_Base+=Read_leng ;
				for(int jj=0 ; jj<Read_leng ; jj++)
				{
					if (inf[9][jj]=='N'){continue ;}
					int key_depth= position - Start_Ai + jj -1 ;
					Uniqdepth[key_depth]++;
				}
			}
			getline(IN, linesoap ) ;
			istringstream isoneA (linesoap,istringstream::in);
			isoneA>>ID>>Flag>>Nowchr>>position ;
		}

		if (End_Ai> (Chr_Length))
		{
			End_Ai=Chr_Length;
		}

		for ( ubit64_t iee = Start_Ai   ; iee < End_Ai ; iee++ )
		{
			int ie = iee-Start_Ai ;
			if (depth[ie]!=0) 
			{
				All_coverage++;
				Depth<<iee+1<<"\t"<<depthA[ie]<<"\t"<<depthC[ie]<<"\t"<<depthT[ie]<<"\t"<<depthG[ie]<<endl;
			}
			if (Uniqdepth[ie]!=0) { Uniq_coverage++; }
			map <int,DepthDis> :: iterator it=DepDis.find(depth[ie]);
			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DA=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(depth[ie],tmp));
			}
			else
			{
				(it->second).DA++;
			}

			it=DepDis.find(Uniqdepth[ie]);

			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DB=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(Uniqdepth[ie],tmp));
			}
			else
			{
				(it->second).DB++;
			}
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
			depthC[ie]=0 ;depthA[ie]=0 ;depthT[ie]=0 ;depthG[ie]=0 ;
		}
		//        Depth<<endl;
		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			depth[tmpj]=depth[ie];
			depthA[tmpj]=depthA[ie];
			depthC[tmpj]=depthC[ie];
			depthT[tmpj]=depthT[ie];
			depthG[tmpj]=depthG[ie];
			Uniqdepth[tmpj]=Uniqdepth[ie];
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
			depthC[ie]=0 ;depthA[ie]=0 ;depthT[ie]=0 ;depthG[ie]=0 ;
		}
		if  (Nowchr!=chr)
		{
			break;
		}
	} 

	/// print out ///
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<chr<<"\t"<<Uniq_Base*1.0/Eff_length<<"\t"<<Uniq_coverage*100.0/Eff_length<<"\t"<<Uniq_Base<<"\t"<<Uniq_coverage<<"\t"<<Uniq_Read<<"\t";
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<All_Base*1.0/Eff_length<<"\t"<<All_coverage*100.0/Eff_length<<"\t"<<All_Base<<"\t"<<All_coverage<<"\t"<<All_Read<<"\t"<<Eff_length<<"\t"<<Chr_Length<<endl ;

	delete [] depth ;
	delete [] depthA ;
	delete [] depthC ;
	delete [] depthT ;
	delete [] depthG ;
	delete [] Uniqdepth ;
	chr=Nowchr ;
	if ((!IN.eof())) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}



////
int  StatSam_Arg (map<int,DepthDis> & DepDis , ubit64_t Chr_Length , ubit64_t Eff_length , string &  chr , igzstream &  IN , ofstream & OUT  , string  & linesoap   )
{

	ubit64_t Uniq_Read=0  ;
	ubit64_t All_Read=0  ;
	ubit64_t Uniq_Base=0  ;
	ubit64_t All_Base =0 ;
	//    ubit64_t Uniq_MisMatch =0 ;
	//ubit64_t All_MisMatch =0 ;
	ubit64_t Uniq_coverage=0 ;
	ubit64_t All_coverage=0 ;

	int WindosL=5000000, maxReadLength=20000;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;
	//  int windos_Amax=bin-1*maxReadLength;

	//ubit64_t  Start=0 , End=Start+bin-3*ReadMax , End_Aadd=Start+bin-2*ReadMax ;

	//  map <string , llong >  MisMatchMap ; 
	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	int *depth= new int[bin];
	int *Uniqdepth= new int[bin];
	memset (depth , 0 , sizeof(int)*bin);
	memset (Uniqdepth, 0 , sizeof(int)*bin);

	string  Nowchr ;
	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++ )
	{
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID , Flag ;
		int hit , Read_leng ;
		istringstream isoneA (linesoap,istringstream::in);
		isoneA>>ID>>Flag>>Nowchr>>position ;
		if (Nowchr!=chr) {break;}
		while( (!IN.eof()) && position<=End_Ai  &&  Nowchr==chr ) 
		{
			vector<string> inf;
			split(linesoap,inf," \t");
			Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
			position=atol(inf[3].c_str());
			Read_leng=inf[9].size();
			if(Read_leng>maxReadLength)
			{
				getline(IN, linesoap );
				istringstream isoneA (linesoap,istringstream::in);
				isoneA>>ID>>Flag>>Nowchr>>position ;
				continue ;
			}
			int vec_size=inf.size();

			for (int i = 11; i < vec_size ; i++) {
				if (inf[i].find(HIT_COUNT_XA) != std::string::npos)
				{
					vector <string> tmp ;
					split( inf[i] ,  tmp , ";");
					hit=1+tmp.size();
					break;
				}
				else if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTU)!= std::string::npos)
				{
					hit =1;
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTR)!= std::string::npos)
				{
					hit =2;
					break;
				}
			}


			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}

			All_Read++  ;
			All_Base+=Read_leng ;
			//int MisMatchDD=stat_AMisMatch (linesoap, Nowchr , MisMatchMap);
			//All_MisMatch+=MisMatchDD ;

			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				if (inf[9][jj]=='N'){continue ;}
				int key_depth= Stat_vetor  + jj  ;
				depth[key_depth]++;
			}

			if (hit==1)
			{
				Uniq_Read++;
				Uniq_Base+=Read_leng ;
				//              Uniq_MisMatch+=MisMatchDD ;
				for(int jj=0 ; jj<Read_leng ; jj++)
				{
					if (inf[9][jj]=='N'){continue ;}
					int key_depth= position - Start_Ai + jj -1 ;
					Uniqdepth[key_depth]++;
				}
			}
			getline(IN, linesoap ) ;
			istringstream isoneA (linesoap,istringstream::in);
			isoneA>>ID>>Flag>>Nowchr>>position ;

		}

		if (End_Ai> (Chr_Length))
		{
			End_Ai=Chr_Length;
		}


		for ( ubit64_t iee = Start_Ai   ; iee < End_Ai ; iee++ )
		{
			int ie = iee-Start_Ai ;
			if (depth[ie]!=0) {All_coverage++;}
			if (Uniqdepth[ie]!=0) { Uniq_coverage++; }
			map <int,DepthDis> :: iterator it=DepDis.find(depth[ie]);
			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DA=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(depth[ie],tmp));
			}
			else
			{
				(it->second).DA++;
			}

			it=DepDis.find(Uniqdepth[ie]);

			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DB=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(Uniqdepth[ie],tmp));
			}
			else
			{
				(it->second).DB++;
			}
			//DepDis 
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}

		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			depth[tmpj]=depth[ie];
			Uniqdepth[tmpj]=Uniqdepth[ie];
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}

		if  (Nowchr!=chr)
		{
			break;
		}

	}

	/// print out ///
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<chr<<"\t"<<Uniq_Base*1.0/Eff_length<<"\t"<<Uniq_coverage*100.0/Eff_length<<"\t"<<Uniq_Base<<"\t"<<Uniq_coverage<<"\t"<<Uniq_Read<<"\t";
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<All_Base*1.0/Eff_length<<"\t"<<All_coverage*100.0/Eff_length<<"\t"<<All_Base<<"\t"<<All_coverage<<"\t"<<All_Read<<"\t"<<Eff_length<<"\t"<<Chr_Length<<endl ;

	chr=Nowchr ;

	delete [] depth ;
	delete [] Uniqdepth ;

	if ((!IN.eof())) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}







//////////////////////////////Bam /////////////////



int  StatBam_Arg_2 ( map<int,DepthDis> & DepDis  , ubit64_t Chr_Length , ubit64_t Eff_length , string  & chr , TSamCtrl  &  IN , ofstream & OUT  , string  & linesoap  , ogzstream  & Depth )
{

	ubit64_t Uniq_Read=0  ;
	ubit64_t All_Read=0  ;
	ubit64_t Uniq_Base=0  ;
	ubit64_t All_Base =0 ;
	ubit64_t Uniq_coverage=0 ;
	ubit64_t All_coverage=0 ;

	int WindosL=5000000, maxReadLength=20000;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;
	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	int *depth= new int[bin];
	int *Uniqdepth= new int[bin];
	memset (depth , 0 , sizeof(int)*bin);
	memset (Uniqdepth, 0 , sizeof(int)*bin);
	string  Nowchr ;
	Depth<<">"<<chr<<endl;
	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++ )
	{   
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID , Flag  ;
		int hit , Read_leng ;
		istringstream isoneA (linesoap,istringstream::in);
		isoneA>>ID>>Flag>>Nowchr>>position ;
		while( (IN.isOpened()) && position<=End_Ai  &&  Nowchr==chr ) 
		{
			vector<string> inf;
			split(linesoap,inf," \t");
			Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
			position=atol(inf[3].c_str());
			Read_leng=inf[9].size();
			if(Read_leng>maxReadLength)
			{
				IN.readline(linesoap);
				istringstream isoneA (linesoap,istringstream::in);
				isoneA>>ID>>Flag>>Nowchr>>position ;
				continue ;
			}
			int vec_size=inf.size();
			hit = 1;
			for (int i = 11; i < vec_size ; i++) {
				if (inf[i].find(HIT_COUNT_XA) != std::string::npos)
				{
					vector <string> tmp ;
					split( inf[i] ,  tmp , ";");
					hit=1+tmp.size();
					break;
				}
				else if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTU)!= std::string::npos)
				{
					hit =1;
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTR)!= std::string::npos)
				{
					hit =2;
					break;
				}
			}



			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}

			All_Read++  ;
			All_Base+=Read_leng ;

			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				if (inf[9][jj]=='N'){continue ;}
				int key_depth= Stat_vetor  + jj  ;
				depth[key_depth]++;
			}

			if (hit==1)
			{
				Uniq_Read++;
				Uniq_Base+=Read_leng ;
				for(int jj=0 ; jj<Read_leng ; jj++)
				{
					if (inf[9][jj]=='N'){continue ;}
					int key_depth= position - Start_Ai + jj -1 ;
					Uniqdepth[key_depth]++;
				}
			}
			IN.readline(linesoap);
			istringstream isoneA (linesoap,istringstream::in);
			isoneA>>ID>>Flag>>Nowchr>>position ;
		}

		if (End_Ai> (Chr_Length))
		{
			End_Ai=Chr_Length;
		}

		for ( ubit64_t iee = Start_Ai   ; iee < End_Ai ; iee++ )
		{
			int ie = iee-Start_Ai ;
			if (depth[ie]!=0) {All_coverage++;}
			if (Uniqdepth[ie]!=0) { Uniq_coverage++; }
			map <int,DepthDis> :: iterator it=DepDis.find(depth[ie]);
			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DA=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(depth[ie],tmp));
			}
			else
			{
				(it->second).DA++;
			}

			it=DepDis.find(Uniqdepth[ie]);

			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DB=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(Uniqdepth[ie],tmp));
			}
			else
			{
				(it->second).DB++;
			}

			Depth<<Uniqdepth[ie]<<" ";
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}
		Depth<<endl;
		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			depth[tmpj]=depth[ie];
			Uniqdepth[tmpj]=Uniqdepth[ie];
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}
		if  (Nowchr!=chr)
		{
			break;
		}
	} 

	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<chr<<"\t"<<Uniq_Base*1.0/Eff_length<<"\t"<<Uniq_coverage*100.0/Eff_length<<"\t"<<Uniq_Base<<"\t"<<Uniq_coverage<<"\t"<<Uniq_Read<<"\t";
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<All_Base*1.0/Eff_length<<"\t"<<All_coverage*100.0/Eff_length<<"\t"<<All_Base<<"\t"<<All_coverage<<"\t"<<All_Read<<"\t"<<Eff_length<<"\t"<<Chr_Length<<endl ;

	chr=Nowchr ;

	delete [] depth ;
	delete [] Uniqdepth ;

	if (IN.isOpened()) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}









//////////


int  StatBam_Arg_1 (  map<int,DepthDis> & DepDis ,ubit64_t Chr_Length , ubit64_t Eff_length , string & chr , TSamCtrl &  IN , ofstream & OUT  , string  & linesoap  , ogzstream  & Depth  )
{

	ubit64_t Uniq_Read=0  ;
	ubit64_t All_Read=0  ;
	ubit64_t Uniq_Base=0  ;
	ubit64_t All_Base =0 ;
	ubit64_t Uniq_coverage=0 ;
	ubit64_t All_coverage=0 ;

	int WindosL=5000000, maxReadLength=20000;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;

	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	int *depth= new int[bin];
	int *Uniqdepth= new int[bin];
	memset (depth , 0 , sizeof(int)*bin);
	memset (Uniqdepth, 0 , sizeof(int)*bin);

	string  Nowchr ;
	Depth<<">"<<chr<<endl;
	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++)
	{   
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID ,Flag ;
		int hit , Read_leng ;
		istringstream isoneA (linesoap,istringstream::in);
		isoneA>>ID>>Flag>>Nowchr>>position ;
		while( (IN.isOpened()) && position<=End_Ai  &&  Nowchr==chr ) 
		{
			vector<string> inf;
			split(linesoap,inf," \t");
			Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
			position=atol(inf[3].c_str());
			Read_leng=inf[9].size();
			if(Read_leng>maxReadLength)
			{
				IN.readline(linesoap);
				istringstream isoneA (linesoap,istringstream::in);
				isoneA>>ID>>Flag>>Nowchr>>position ;
				continue ;
			}
			int vec_size=inf.size();
			hit = 1;
			for (int i = 11; i < vec_size ; i++) {
				if (inf[i].find(HIT_COUNT_XA) != std::string::npos)
				{
					vector <string> tmp ;
					split( inf[i] ,  tmp , ";");
					hit=1+tmp.size();
					break;
				}
				else if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTU)!= std::string::npos)
				{
					hit =1;
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTR)!= std::string::npos)
				{
					hit =2;
					break;
				}
			}



			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}

			All_Read++ ;
			All_Base+=Read_leng ;

			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				if (inf[9][jj]=='N'){continue ;}
				int key_depth= Stat_vetor  + jj  ;
				depth[key_depth]++;
			}

			if (hit==1)
			{
				Uniq_Read++;
				Uniq_Base+=Read_leng ;
				for(int jj=0 ; jj<Read_leng ; jj++)
				{
					if (inf[9][jj]=='N'){continue ;}
					int key_depth= position - Start_Ai + jj -1 ;
					Uniqdepth[key_depth]++;
				}
			}
			IN.readline(linesoap);
			istringstream isoneA (linesoap,istringstream::in);
			isoneA>>ID>>Flag>>Nowchr>>position ;
		}

		if (End_Ai> (Chr_Length))
		{
			End_Ai=Chr_Length;
		}

		for ( ubit64_t iee = Start_Ai   ; iee < End_Ai ; iee++ )
		{
			int ie = iee-Start_Ai ;
			if (depth[ie]!=0) {All_coverage++;}
			if (Uniqdepth[ie]!=0) { Uniq_coverage++; }
			Depth<<depth[ie]<<" ";
			map <int,DepthDis> :: iterator it=DepDis.find(depth[ie]);
			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DA=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(depth[ie],tmp));
			}
			else
			{
				(it->second).DA++;
			}

			it=DepDis.find(Uniqdepth[ie]);

			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DB=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(Uniqdepth[ie],tmp));
			}
			else
			{
				(it->second).DB++;
			}

			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}
		Depth<<endl;
		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			depth[tmpj]=depth[ie];
			Uniqdepth[tmpj]=Uniqdepth[ie];
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}
		if  (Nowchr!=chr)
		{
			break;
		}
	}

	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<chr<<"\t"<<Uniq_Base*1.0/Eff_length<<"\t"<<Uniq_coverage*100.0/Eff_length<<"\t"<<Uniq_Base<<"\t"<<Uniq_coverage<<"\t"<<Uniq_Read<<"\t";
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<All_Base*1.0/Eff_length<<"\t"<<All_coverage*100.0/Eff_length<<"\t"<<All_Base<<"\t"<<All_coverage<<"\t"<<All_Read<<"\t"<<Eff_length<<"\t"<<Chr_Length<<endl ;


	delete [] depth ;
	delete [] Uniqdepth ;
	chr=Nowchr ;
	if (IN.isOpened()) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}


int  StatBam_Arg (map<int,DepthDis> & DepDis , ubit64_t Chr_Length , ubit64_t Eff_length , string &  chr , TSamCtrl &  IN , ofstream & OUT  , string  & linesoap   )
{

	ubit64_t Uniq_Read=0  ;
	ubit64_t All_Read=0  ;
	ubit64_t Uniq_Base=0  ;
	ubit64_t All_Base =0 ;
	ubit64_t Uniq_coverage=0 ;
	ubit64_t All_coverage=0 ;

	int WindosL=5000000, maxReadLength=20000;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;
	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	int *depth= new int[bin];
	int *Uniqdepth= new int[bin];
	memset (depth , 0 , sizeof(int)*bin);
	memset (Uniqdepth, 0 , sizeof(int)*bin);

	string  Nowchr ;
	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++ )
	{   
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID , Flag ;
		int hit , Read_leng ;
		istringstream isoneA (linesoap,istringstream::in);
		isoneA>>ID>>Flag>>Nowchr>>position ;
		while( (IN.isOpened()) && position<=End_Ai  &&  Nowchr==chr ) 
		{
			vector<string> inf;
			split(linesoap,inf," \t");
			Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
			position=atol(inf[3].c_str());
			Read_leng=inf[9].size();
			if(Read_leng>maxReadLength)
			{
				IN.readline(linesoap);
				istringstream isoneA (linesoap,istringstream::in);
				isoneA>>ID>>Flag>>Nowchr>>position ;
				continue ;
			}
			int vec_size=inf.size();
			hit = 1;

			for (int i = 11; i < vec_size ; i++) {
				if (inf[i].find(HIT_COUNT_XA) != std::string::npos)
				{
					vector <string> tmp ;
					split( inf[i] ,  tmp , ";");
					hit=1+tmp.size();
					break;
				}
				else if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTU)!= std::string::npos)
				{
					hit =1;
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTR)!= std::string::npos)
				{
					hit =2;
					break;
				}
			}




			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}

			All_Read++  ;
			All_Base+=Read_leng ;

			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				if (inf[9][jj]=='N'){continue ;}
				int key_depth= Stat_vetor  + jj  ;
				depth[key_depth]++;
			}

			if (hit==1)
			{
				Uniq_Read++;
				Uniq_Base+=Read_leng ;
				for(int jj=0 ; jj<Read_leng ; jj++)
				{
					if (inf[9][jj]=='N'){continue ;}
					int key_depth= position - Start_Ai + jj -1 ;
					Uniqdepth[key_depth]++;
				}
			}
			IN.readline(linesoap);
			istringstream isoneA (linesoap,istringstream::in);
			isoneA>>ID>>Flag>>Nowchr>>position ;
		}


		if (End_Ai> (Chr_Length))
		{
			End_Ai=Chr_Length;
		}


		for ( ubit64_t iee = Start_Ai   ; iee < End_Ai ; iee++ )
		{
			int ie = iee-Start_Ai ;
			if (depth[ie]!=0) {All_coverage++;}
			if (Uniqdepth[ie]!=0) { Uniq_coverage++; }
			map <int,DepthDis> :: iterator it=DepDis.find(depth[ie]);
			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DA=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(depth[ie],tmp));
			}
			else
			{
				(it->second).DA++;
			}

			it=DepDis.find(Uniqdepth[ie]);

			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DB=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(Uniqdepth[ie],tmp));
			}
			else
			{
				(it->second).DB++;
			}
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}

		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			depth[tmpj]=depth[ie];
			Uniqdepth[tmpj]=Uniqdepth[ie];
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
		}
		if  (Nowchr!=chr)
		{
			break;
		}
	} 

	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<chr<<"\t"<<Uniq_Base*1.0/Eff_length<<"\t"<<Uniq_coverage*100.0/Eff_length<<"\t"<<Uniq_Base<<"\t"<<Uniq_coverage<<"\t"<<Uniq_Read<<"\t";
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<All_Base*1.0/Eff_length<<"\t"<<All_coverage*100.0/Eff_length<<"\t"<<All_Base<<"\t"<<All_coverage<<"\t"<<All_Read<<"\t"<<Eff_length<<"\t"<<Chr_Length<<endl ;

	chr=Nowchr ;

	delete [] depth ;
	delete [] Uniqdepth ;

	if (IN.isOpened()) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}










int  StatBam_Arg_3 (  map<int,DepthDis> & DepDis ,ubit64_t Chr_Length , ubit64_t Eff_length , string & chr , TSamCtrl &  IN , ofstream & OUT  , string  & linesoap  , ogzstream  & Depth  )
{

	ubit64_t Uniq_Read=0  ;
	ubit64_t All_Read=0  ;
	ubit64_t Uniq_Base=0  ;
	ubit64_t All_Base =0 ;
	ubit64_t Uniq_coverage=0 ;
	ubit64_t All_coverage=0 ;

	int WindosL=5000000, maxReadLength=20000;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;

	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	int *depth= new int[bin];
	int *depthA= new int[bin];
	int *depthC= new int[bin];
	int *depthT= new int[bin];
	int *depthG= new int[bin];

	int *Uniqdepth= new int[bin];
	memset (depth , 0 , sizeof(int)*bin);
	memset (depthA , 0 , sizeof(int)*bin);
	memset (depthC , 0 , sizeof(int)*bin);
	memset (depthT , 0 , sizeof(int)*bin);
	memset (depthG , 0 , sizeof(int)*bin);
	memset (Uniqdepth, 0 , sizeof(int)*bin);

	string  Nowchr ;
	Depth<<">"<<chr<<"   #Format:position A_Depth C_Depth T_Depth G_Depth"<<endl;

	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++)
	{   
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID ,Flag ;
		int hit , Read_leng ;
		istringstream isoneA (linesoap,istringstream::in);
		isoneA>>ID>>Flag>>Nowchr>>position ;
		while( (IN.isOpened()) && position<=End_Ai  &&  Nowchr==chr )
		{
			vector<string> inf;
			split(linesoap,inf," \t");
			Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
			position=atol(inf[3].c_str());
			Read_leng=inf[9].size();

			if(Read_leng>maxReadLength)
			{
				IN.readline(linesoap);
				istringstream isoneA (linesoap,istringstream::in);
				isoneA>>ID>>Flag>>Nowchr>>position ;
				continue ;
			}

			int vec_size=inf.size();
			hit = 1;

			for (int i = 11; i < vec_size ; i++) {
				if (inf[i].find(HIT_COUNT_XA) != std::string::npos)
				{
					vector <string> tmp ;
					split( inf[i] ,  tmp , ";");
					hit=1+tmp.size();
					break;
				}
				else if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTU)!= std::string::npos)
				{
					hit =1;
					break;
				}
				else if (inf[i].find(HIT_COUNT_XTR)!= std::string::npos)
				{
					hit =2;
					break;
				}
			}




			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}

			All_Read++ ;
			All_Base+=Read_leng ;

			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				if (inf[9][jj]=='N'){continue ;}
				int key_depth= Stat_vetor  + jj  ;
				depth[key_depth]++;
				if (inf[9][jj] == 'A')
				{
					depthA[key_depth]++;
				}
				else if (inf[9][jj] == 'C')
				{
					depthC[key_depth]++;
				}
				else if (inf[9][jj] == 'T')
				{
					depthT[key_depth]++;
				}
				else if(inf[9][jj] == 'G')
				{
					depthG[key_depth]++;
				}
			}

			if (hit==1)
			{
				Uniq_Read++;
				Uniq_Base+=Read_leng ;
				for(int jj=0 ; jj<Read_leng ; jj++)
				{
					if (inf[9][jj]=='N'){continue ;}
					int key_depth= position - Start_Ai + jj -1 ;
					Uniqdepth[key_depth]++;
				}
			}

			IN.readline(linesoap);
			istringstream isoneA (linesoap,istringstream::in);
			isoneA>>ID>>Flag>>Nowchr>>position ;
		}

		if (End_Ai> (Chr_Length))
		{
			End_Ai=Chr_Length;
		}

		for ( ubit64_t iee = Start_Ai   ; iee < End_Ai ; iee++ )
		{
			int ie = iee-Start_Ai ;
			if (depth[ie]!=0) 
			{
				All_coverage++;
				Depth<<iee+1<<"\t"<<depthA[ie]<<"\t"<<depthC[ie]<<"\t"<<depthT[ie]<<"\t"<<depthG[ie]<<endl;
			}
			if (Uniqdepth[ie]!=0) { Uniq_coverage++; }

			map <int,DepthDis> :: iterator it=DepDis.find(depth[ie]);
			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DA=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(depth[ie],tmp));
			}
			else
			{
				(it->second).DA++;
			}

			it=DepDis.find(Uniqdepth[ie]);

			if (it == DepDis.end() )
			{
				DepthDis tmp;
				tmp.DB=1;
				DepDis.insert(map <int ,DepthDis> :: value_type(Uniqdepth[ie],tmp));
			}
			else
			{
				(it->second).DB++;
			}
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
			depthC[ie]=0 ;depthA[ie]=0 ;depthT[ie]=0 ;depthG[ie]=0 ;
		}
		//        Depth<<endl;
		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			depth[tmpj]=depth[ie];
			Uniqdepth[tmpj]=Uniqdepth[ie];
			depthA[tmpj]=depthA[ie];
			depthC[tmpj]=depthC[ie];
			depthT[tmpj]=depthT[ie];
			depthG[tmpj]=depthG[ie];
			depth[ie]=0 ; Uniqdepth[ie]=0 ;
			depthC[ie]=0 ;depthA[ie]=0 ;depthT[ie]=0 ;depthG[ie]=0 ;
		}
		if  (Nowchr!=chr)
		{
			break;
		}
	}

	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<chr<<"\t"<<Uniq_Base*1.0/Eff_length<<"\t"<<Uniq_coverage*100.0/Eff_length<<"\t"<<Uniq_Base<<"\t"<<Uniq_coverage<<"\t"<<Uniq_Read<<"\t";
	OUT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<All_Base*1.0/Eff_length<<"\t"<<All_coverage*100.0/Eff_length<<"\t"<<All_Base<<"\t"<<All_coverage<<"\t"<<All_Read<<"\t"<<Eff_length<<"\t"<<Chr_Length<<endl ;


	delete [] depth ;
	delete [] depthA ;
	delete [] depthC ;
	delete [] depthT ;
	delete [] depthG ;
	delete [] Uniqdepth ;
	chr=Nowchr ;
	if (IN.isOpened()) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}



////////////////////////////Bam //////////////////

int Xam_Stat_main(int argc, char **argv) 
	//int main(int argc, char **argv) 
{
	Para_Xam05 * para_Xam05 = new Para_Xam05;
	if (parse_Acmd_Xam05( argc, argv , para_Xam05 ) ==0 )
	{
		delete para_Xam05 ; 
		return 0 ;
	}
	ofstream OUT ((para_Xam05->OutStat).c_str());
	if(!OUT.good())
	{
		cerr << "open OutPutFile error: "<<(para_Xam05->OutStat)<<endl;
		return 0 ;
	}  
	map <string,ubit64_t>  ChrLeng ;
	map <string,ubit64_t>  ChrEffL ;   
	OpenChr (para_Xam05->Ref ,  ChrLeng , ChrEffL ) ;

	vector <string> FileStort ;
	if ((!((para_Xam05->InList).empty())))
	{
		ReadList (para_Xam05->InList , FileStort  ) ;
	}
	if ((!((para_Xam05->InFile).empty())))
	{
		FileStort.push_back((para_Xam05->InFile));
	}

	OUT<<"##Chr\tUniqDepth(X)\tUniqCov(%)\tUniqBase\tUniqCovBase\tUniqRead\tAllDepth(X)\tAllCov(%)\tAllBase\tAllCovBase\tAllRead\tChrEffL\tChrLength\n" ;
	map <int , DepthDis > HashDis ;

	int Soap_AStat_Acount=FileStort.size();
	if ((para_Xam05->ISSam))
	{
		for (int iFile=0; iFile<Soap_AStat_Acount ; iFile++)
		{
			string SoapStat_ANow=FileStort[iFile];
			igzstream SOAP (SoapStat_ANow.c_str(),ifstream::in);
			if(!SOAP.good())
			{
				cerr << "open InputFile error: "<<SoapStat_ANow<<endl;
				return 0 ;
			}

			string ID ,Flag,Nowchr,soapline;
			ubit64_t position =0;
			while(!SOAP.eof())
			{
				getline(SOAP,soapline) ;
				if (soapline[0] != '@')
				{
					istringstream isoneA (soapline,istringstream::in);
					isoneA>>ID>>Flag>>Nowchr>>position;
					if (Nowchr!="*")
					{
						break;
					}
				}
			}

			if ((para_Xam05->SiteD)==1)
			{
				string OutDepth=(para_Xam05->OutStat)+".depth.fa.gz";
				ogzstream Depth (OutDepth.c_str());
				if((!Depth.good()))
				{
					cerr << "open InputFile error: "<<OutDepth<<endl;
					return 0;
				}  
				int run=StatSam_Arg_1 ( HashDis  , ChrLeng[Nowchr] ,ChrEffL[Nowchr] ,Nowchr ,SOAP ,OUT , soapline, Depth );

				while(run)
				{
					run=StatSam_Arg_1 ( HashDis , ChrLeng[Nowchr] , ChrEffL[Nowchr] , Nowchr , SOAP ,OUT , soapline, Depth );
				}

				Depth.close();

			}
			else if ( (para_Xam05->SiteD)==2)
			{
				string OutDepth=(para_Xam05->OutStat)+".depth.fa.gz";
				ogzstream Depth (OutDepth.c_str());
				if((!Depth.good()))
				{
					cerr << "open InputFile error: "<<OutDepth<<endl;
					return 0;
				}  
				int run=StatSam_Arg_2 ( HashDis , ChrLeng[Nowchr] ,ChrEffL[Nowchr] ,Nowchr ,SOAP ,OUT , soapline, Depth );
				while(run)
				{
					run=StatSam_Arg_2 ( HashDis , ChrLeng[Nowchr] , ChrEffL[Nowchr] , Nowchr , SOAP ,OUT , soapline, Depth );
				}
				Depth.close();
			}
			else if ( (para_Xam05->SiteD)==3)
			{
				string OutDepth=(para_Xam05->OutStat)+".depth.fa.gz";
				ogzstream Depth (OutDepth.c_str());
				if((!Depth.good()))
				{
					cerr << "open InputFile error: "<<OutDepth<<endl;
					return 0;
				}  
				int run=StatSam_Arg_3 ( HashDis , ChrLeng[Nowchr] ,ChrEffL[Nowchr] ,Nowchr ,SOAP ,OUT , soapline, Depth );
				while(run)
				{
					run=StatSam_Arg_3 ( HashDis , ChrLeng[Nowchr] , ChrEffL[Nowchr] , Nowchr , SOAP ,OUT , soapline, Depth );
				}
				Depth.close();
			}
			else 
			{
				int run=StatSam_Arg ( HashDis , ChrLeng[Nowchr] ,ChrEffL[Nowchr] ,Nowchr ,SOAP ,OUT , soapline);
				while(run)
				{
					run=StatSam_Arg ( HashDis , ChrLeng[Nowchr] , ChrEffL[Nowchr] , Nowchr , SOAP ,OUT , soapline);
				}
			}

			SOAP.close();
			SOAP.clear();

		}
	}
	else
	{
		char in_mode[5] ={ 0 };     in_mode[0]='r'; in_mode[1]='b';

		for (int iFile=0; iFile<Soap_AStat_Acount ; iFile++)
		{
			string SoapStat_ANow=FileStort[iFile];
			TSamCtrl SOAP ;
			SOAP.open(SoapStat_ANow.c_str(),in_mode);
			string ID ,Flag,Nowchr,soapline;
			ubit64_t position =0;

			while(SOAP.readline(soapline)!=-1)
			{
				string tmp = Talignment_format(soapline);
				if (tmp.compare(NOUSE_ALIGNMENT)==0)
				{
					continue;
				}
				else
				{
					break ;
				}
			}

			istringstream isoneA (soapline,istringstream::in);
			isoneA>>ID>>Flag>>Nowchr>>position ;

			if ((para_Xam05->SiteD)==1)
			{
				string OutDepth=(para_Xam05->OutStat)+".depth.fa.gz";
				ogzstream Depth (OutDepth.c_str());
				if((!Depth.good()))
				{
					cerr << "open InputFile error: "<<OutDepth<<endl;
					return 0;
				}  
				int run=StatBam_Arg_1 ( HashDis  , ChrLeng[Nowchr] ,ChrEffL[Nowchr] ,Nowchr ,SOAP ,OUT , soapline, Depth );

				while(run)
				{
					run=StatBam_Arg_1 ( HashDis , ChrLeng[Nowchr] , ChrEffL[Nowchr] , Nowchr , SOAP ,OUT , soapline, Depth );
				}

				Depth.close();

			}
			else if ( (para_Xam05->SiteD)==2)
			{
				string OutDepth=(para_Xam05->OutStat)+".depth.gz";
				ogzstream Depth (OutDepth.c_str());
				if((!Depth.good()))
				{
					cerr << "open InputFile error: "<<OutDepth<<endl;
					return 0;
				}  
				int run=StatBam_Arg_2 ( HashDis , ChrLeng[Nowchr] ,ChrEffL[Nowchr] ,Nowchr ,SOAP ,OUT , soapline, Depth );
				while(run)
				{
					run=StatBam_Arg_2 ( HashDis , ChrLeng[Nowchr] , ChrEffL[Nowchr] , Nowchr , SOAP ,OUT , soapline, Depth );
				}
				Depth.close();
			}
			else if ( (para_Xam05->SiteD)==3)
			{
				string OutDepth=(para_Xam05->OutStat)+".depth.gz";
				ogzstream Depth (OutDepth.c_str());
				if((!Depth.good()))
				{
					cerr << "open InputFile error: "<<OutDepth<<endl;
					return 0;
				}  
				int run=StatBam_Arg_3 ( HashDis , ChrLeng[Nowchr] ,ChrEffL[Nowchr] ,Nowchr ,SOAP ,OUT , soapline, Depth );
				while(run)
				{
					run=StatBam_Arg_3 ( HashDis , ChrLeng[Nowchr] , ChrEffL[Nowchr] , Nowchr , SOAP ,OUT , soapline, Depth );
				}
				Depth.close();
			}
			else 
			{
				int run=StatBam_Arg ( HashDis , ChrLeng[Nowchr] ,ChrEffL[Nowchr] ,Nowchr ,SOAP ,OUT , soapline);
				while(run)
				{
					run=StatBam_Arg ( HashDis , ChrLeng[Nowchr] , ChrEffL[Nowchr] , Nowchr , SOAP ,OUT , soapline);
				}
			}
			SOAP.close();
		}
	}

	OUT.close();


	/////////////////////////////////////////////////////////////////////////

	igzstream TT ((para_Xam05->OutStat).c_str(),ifstream::in);
	if(!TT.good())
	{
		cerr <<"Open InputFile error: "<<(para_Xam05->OutStat)<<endl;        
	} 

	ubit64_t  Sum_Uniq_Base=0,Sum_Uniq_coverage=0 ,Sum_Uniq_Read=0, Sum_All_Base=0,Sum_All_coverage=0 , Sum_All_Read=0 , Sum_Eff_length=0, Sum_Chr_Length =0 ;

	while( (!TT.eof()) ) 
	{
		string  line ;
		getline(TT,line);
		if (line.length()<=0 || line[0]=='#' ) { continue ; }
		string chr ,tempA ,tempB,tempC,tempD;
		ubit64_t Uniq_Base=0,Uniq_Read=0, All_Base=0,All_Read=0 , Eff_length=0, Chr_Length =0 ,Uniq_coverage=0, All_coverage=0 ;
		istringstream isone (line,istringstream::in);
		isone>>chr>>tempA>>tempB>>Uniq_Base>>Uniq_coverage>>Uniq_Read>>tempC>>tempD>>All_Base>>All_coverage>>All_Read>>Eff_length>>Chr_Length ;
		Sum_Uniq_Base+=Uniq_Base ; Sum_Uniq_Read+=Uniq_Read;
		Sum_All_Base+=All_Base ; Sum_All_Read+=All_Read;
		Sum_Eff_length+=Eff_length ; Sum_Chr_Length+=Chr_Length ;
		Sum_Uniq_coverage+=Uniq_coverage;
		Sum_All_coverage+=All_coverage ;
	}
	TT.close();


	ofstream TTT ((para_Xam05->OutStat).c_str(),ios::app);
	if(!TTT.good())
	{
		cerr <<"Open InputFile error: "<<(para_Xam05->OutStat)<<endl;        
	} 

	TTT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<"#Genome\t"<<Sum_Uniq_Base*1.0/Sum_Eff_length<<"\t"<<Sum_Uniq_coverage*100.0/Sum_Eff_length<<"\t"<<Sum_Uniq_Base<<"\t"<<Sum_Uniq_coverage<<"\t"<<Sum_Uniq_Read<<"\t";
	TTT<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<Sum_All_Base*1.0/Sum_Eff_length<<"\t"<<Sum_All_coverage*100.0/Sum_Eff_length<<"\t"<<Sum_All_Base<<"\t"<<Sum_All_coverage<<"\t"<<Sum_All_Read<<"\t"<<Sum_Eff_length<<"\t"<<Sum_Chr_Length<<endl ;

	TTT.close();


	delete para_Xam05  ;

	map<int,DepthDis>::iterator innerit=HashDis.begin();
	cout<<"##Depth\tDepthNum\tUniqDepthNum\n";
	if ( innerit!=HashDis.end() )
	{
		cout<<"#"<<(innerit->first)<<"\t"<<(innerit->second).DA<<"\t"<<(innerit->second).DB<<endl;
	}
	innerit++;
	for (  ; innerit!=HashDis.end(); innerit ++ )
	{
		cout<<(innerit->first)<<"\t"<<(innerit->second).DA<<"\t"<<(innerit->second).DB<<endl;
	}
	return 1 ;
}


//programme entry
///////// swimming in the sky and flying in the sea ////////////
#endif /* Xam_Stat_H_  */

