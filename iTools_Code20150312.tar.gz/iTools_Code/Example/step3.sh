#!/bin/sh
#$ -S /bin/sh
#Version1.0	hewm@genomics.org.cn	2012-05-19
echo Start Time : 
date '+%F	%H:%M'
../bin/iTools	CNStools	GLFmulti	-GlfList	/ifs5/PC_PA_AP/USER/heweiming/soy31/SoapSNP/list/Gm01.list	-OutPut	/ifs5/PC_PA_AP/USER/heweiming/soy31/SoapSNP/Raw/Gm01.raw.gz	
../bin/iTools	CNStools	Addcn	-InRaw	/ifs5/PC_PA_AP/USER/heweiming/soy31/SoapSNP/Raw/Gm01.raw.gz	-SoapList	/ifs5/PC_PA_AP/USER/heweiming/soy31/SoapBychrSort/List/Gm01.list	-CPU	2	-OutPut	/ifs5/PC_PA_AP/USER/heweiming/soy31/SoapSNP/Raw/Gm01.addcn	-ChrLeng	55915595	
echo End Time : 
date '+%F	%H:%M'
